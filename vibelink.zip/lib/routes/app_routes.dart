import 'package:flutter/material.dart';
import '../presentation/authentication_onboarding/authentication_onboarding.dart';
import '../presentation/home_feed/home_feed.dart';
import '../presentation/events_travel_hub/events_travel_hub.dart';
import '../presentation/create_vibe_event/create_vibe_event.dart';
import '../presentation/profile_search_settings/profile_search_settings.dart';
import '../presentation/messaging_community/messaging_community.dart';
import '../presentation/notification_center/notification_center.dart';
import '../presentation/ticket_wallet/ticket_wallet.dart';
import '../presentation/admin_dashboard/admin_dashboard.dart';
import '../presentation/notification_preferences/notification_preferences_screen.dart';
import '../presentation/organizer_analytics/organizer_analytics_screen.dart';
import '../presentation/event_detail/event_detail_screen.dart';
import '../presentation/event_promotion/event_promotion_screen.dart';
import '../presentation/review_submission/review_submission_screen.dart';

class AppRoutes {
  static const String authenticationOnboarding = '/authentication_onboarding';
  static const String homeFeed = '/home_feed';
  static const String eventsTravelHub = '/events_travel_hub';
  static const String createVibeEvent = '/create_vibe_event';
  static const String messagingCommunity = '/messaging_community';
  static const String profileSearchSettings = '/profile_search_settings';
  static const String notificationCenter = '/notification_center';
  static const String ticketWallet = '/ticket_wallet';
  static const String adminDashboard = '/admin_dashboard';
  static const String notificationPreferences = '/notification_preferences';
  static const String organizerAnalytics = '/organizer_analytics';
  static const String eventDetail = '/event_detail';
  static const String eventPromotion = '/event_promotion';
  static const String reviewSubmission = '/review_submission';

  static Map<String, WidgetBuilder> routes = {
    authenticationOnboarding: (context) => const AuthenticationOnboarding(),
    homeFeed: (context) => const HomeFeed(),
    eventsTravelHub: (context) => const EventsTravelHub(),
    createVibeEvent: (context) => const CreateVibeEvent(),
    messagingCommunity: (context) => const MessagingCommunity(),
    profileSearchSettings: (context) => const ProfileSearchSettings(),
    notificationCenter: (context) => const NotificationCenter(),
    ticketWallet: (context) => const TicketWallet(),
    adminDashboard: (context) => const AdminDashboard(),
    notificationPreferences: (context) => const NotificationPreferencesScreen(),
    organizerAnalytics: (context) => const OrganizerAnalyticsScreen(),
    eventDetail: (context) => const EventDetailScreen(),
    eventPromotion: (context) => const EventPromotionScreen(),
    reviewSubmission: (context) => const ReviewSubmissionScreen(),
  };
}

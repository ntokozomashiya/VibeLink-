import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/oracle_api_service.dart';
import '../../services/oracle_websocket_service.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/notification_item_widget.dart';

/// Notification Center screen displaying push alerts for messages, events,
/// bookings, and ticket confirmations with unread badge counters
class NotificationCenter extends StatefulWidget {
  const NotificationCenter({super.key});

  @override
  State<NotificationCenter> createState() => _NotificationCenterState();
}

class _NotificationCenterState extends State<NotificationCenter>
    with SingleTickerProviderStateMixin {
  int _currentBottomNavIndex = 0;
  late TabController _tabController;
  final OracleWebSocketService _wsService = OracleWebSocketService();
  bool _isLoading = false;
  List<Map<String, dynamic>> _notifications = [];
  Map<String, int> _unreadCounts = {
    'all': 0,
    'messages': 0,
    'events': 0,
    'bookings': 0,
    'tickets': 0,
  };

  final List<Map<String, String>> _categories = [
    {'id': 'all', 'label': 'All', 'icon': 'notifications'},
    {'id': 'messages', 'label': 'Messages', 'icon': 'chat_bubble'},
    {'id': 'events', 'label': 'Events', 'icon': 'event'},
    {'id': 'bookings', 'label': 'Bookings', 'icon': 'book_online'},
    {'id': 'tickets', 'label': 'Tickets', 'icon': 'confirmation_number'},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
    _tabController.addListener(_handleTabChange);
    _initializeNotifications();
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    _wsService.unsubscribeFromNotifications();
    super.dispose();
  }

  Future<void> _initializeNotifications() async {
    if (OracleApiService.isAuthenticated) {
      await _loadUnreadCounts();
      await _loadNotifications();

      try {
        final token = OracleApiService.currentUser?['token'] ?? '';
        if (!_wsService.isConnected) {
          await _wsService.connect(token);
        }
        _wsService.subscribeToNotifications();

        _wsService.messageStream?.listen((message) {
          if (message['type'] == 'notification') {
            _handleIncomingNotification(message);
          } else if (message['type'] == 'notification_read') {
            _handleNotificationRead(message);
          }
        });
      } catch (e) {
        print('WebSocket connection failed: $e');
      }
    }
  }

  Future<void> _loadUnreadCounts() async {
    try {
      final counts = await OracleApiService.getUnreadCountByCategory();
      setState(() {
        _unreadCounts = {
          'all': counts['all'] ?? 0,
          'messages': counts['messages'] ?? 0,
          'events': counts['events'] ?? 0,
          'bookings': counts['bookings'] ?? 0,
          'tickets': counts['tickets'] ?? 0,
        };
      });
    } catch (e) {
      print('Failed to load unread counts: $e');
    }
  }

  Future<void> _loadNotifications() async {
    setState(() => _isLoading = true);

    try {
      final category = _categories[_tabController.index]['id'];
      final notifications = await OracleApiService.fetchNotifications(
        category: category,
      );
      setState(() {
        _notifications = notifications;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      print('Failed to load notifications: $e');
    }
  }

  void _handleIncomingNotification(Map<String, dynamic> notification) {
    if (mounted) {
      setState(() {
        _notifications.insert(0, notification);
        final category = notification['category'] as String;
        _unreadCounts['all'] = (_unreadCounts['all'] ?? 0) + 1;
        _unreadCounts[category] = (_unreadCounts[category] ?? 0) + 1;
      });
    }
  }

  void _handleNotificationRead(Map<String, dynamic> data) {
    if (mounted) {
      final notificationId = data['notification_id'] as int;
      setState(() {
        final index = _notifications.indexWhere(
          (n) => n['id'] == notificationId,
        );
        if (index != -1) {
          _notifications[index]['is_read'] = true;
          final category = _notifications[index]['category'] as String;
          _unreadCounts['all'] = (_unreadCounts['all'] ?? 1) - 1;
          _unreadCounts[category] = (_unreadCounts[category] ?? 1) - 1;
        }
      });
    }
  }

  void _handleTabChange() {
    if (_tabController.indexIsChanging) {
      HapticFeedback.lightImpact();
      _loadNotifications();
    }
  }

  Future<void> _handleMarkAsRead(int notificationId) async {
    try {
      await OracleApiService.markNotificationAsRead(notificationId.toString());
      setState(() {
        final index = _notifications.indexWhere(
          (n) => n['id'] == notificationId,
        );
        if (index != -1 && !(_notifications[index]['is_read'] as bool)) {
          _notifications[index]['is_read'] = true;
          final category = _notifications[index]['category'] as String;
          _unreadCounts['all'] = (_unreadCounts['all'] ?? 1) - 1;
          _unreadCounts[category] = (_unreadCounts[category] ?? 1) - 1;
        }
      });
    } catch (e) {
      print('Failed to mark notification as read: $e');
    }
  }

  Future<void> _handleMarkAllAsRead() async {
    HapticFeedback.mediumImpact();
    try {
      final category = _categories[_tabController.index]['id']!;
      await OracleApiService.markAllNotificationsAsRead(category: category);
      setState(() {
        for (var notification in _notifications) {
          notification['is_read'] = true;
        }
        if (category == 'all') {
          _unreadCounts = {
            'all': 0,
            'messages': 0,
            'events': 0,
            'bookings': 0,
            'tickets': 0,
          };
        } else {
          final count = _unreadCounts[category] ?? 0;
          _unreadCounts['all'] = (_unreadCounts['all'] ?? 0) - count;
          _unreadCounts[category] = 0;
        }
      });
    } catch (e) {
      print('Failed to mark all as read: $e');
    }
  }

  Future<void> _handleDeleteNotification(int notificationId) async {
    try {
      await OracleApiService.deleteNotification(notificationId.toString());
      setState(() {
        final index = _notifications.indexWhere(
          (n) => n['id'] == notificationId,
        );
        if (index != -1) {
          final notification = _notifications[index];
          if (!(notification['is_read'] as bool)) {
            final category = notification['category'] as String;
            _unreadCounts['all'] = (_unreadCounts['all'] ?? 1) - 1;
            _unreadCounts[category] = (_unreadCounts[category] ?? 1) - 1;
          }
          _notifications.removeAt(index);
        }
      });
    } catch (e) {
      print('Failed to delete notification: $e');
    }
  }

  void _handleBottomNavTap(int index) {
    HapticFeedback.lightImpact();
    setState(() => _currentBottomNavIndex = index);

    final routes = [
      AppRoutes.homeFeed,
      AppRoutes.eventsTravelHub,
      AppRoutes.createVibeEvent,
      AppRoutes.messagingCommunity,
      AppRoutes.profileSearchSettings,
    ];

    if (index < routes.length) {
      Navigator.pushReplacementNamed(context, routes[index]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: theme.scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: theme.colorScheme.onSurface,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Notifications',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
            color: theme.colorScheme.onSurface,
          ),
        ),
        actions: [
          if ((_unreadCounts[_categories[_tabController.index]['id']] ?? 0) > 0)
            TextButton(
              onPressed: _handleMarkAllAsRead,
              child: Text(
                'Mark all read',
                style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: theme.colorScheme.primary,
                ),
              ),
            ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: theme.colorScheme.primary,
          labelColor: theme.colorScheme.primary,
          unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
          labelStyle: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
          ),
          tabs: _categories.map((category) {
            final unreadCount = _unreadCounts[category['id']] ?? 0;
            return Tab(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(iconName: category['icon']!, size: 18),
                  SizedBox(width: 1.w),
                  Text(category['label']!),
                  if (unreadCount > 0) ...[
                    SizedBox(width: 1.w),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.error,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      constraints: const BoxConstraints(
                        minWidth: 18,
                        minHeight: 18,
                      ),
                      child: Text(
                        unreadCount > 99 ? '99+' : unreadCount.toString(),
                        style: GoogleFonts.inter(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.onError,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ],
              ),
            );
          }).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: _categories.map((category) {
          return _buildNotificationList(theme);
        }).toList(),
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: _currentBottomNavIndex,
        onTap: _handleBottomNavTap,
        badges: {3: _unreadCounts['messages']?.toString() ?? '0'},
      ),
    );
  }

  Widget _buildNotificationList(ThemeData theme) {
    if (_isLoading) {
      return Center(
        child: CircularProgressIndicator(color: theme.colorScheme.primary),
      );
    }

    if (_notifications.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'notifications_none',
              size: 64,
              color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.5),
            ),
            SizedBox(height: 2.h),
            Text(
              'No notifications yet',
              style: GoogleFonts.inter(
                fontSize: 16.sp,
                fontWeight: FontWeight.w500,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'We\'ll notify you when something arrives',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                color: theme.colorScheme.onSurfaceVariant.withValues(
                  alpha: 0.7,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async {
        await _loadUnreadCounts();
        await _loadNotifications();
      },
      child: ListView.builder(
        padding: EdgeInsets.symmetric(vertical: 1.h),
        itemCount: _notifications.length,
        itemBuilder: (context, index) {
          final notification = _notifications[index];
          return NotificationItemWidget(
            notification: notification,
            onTap: () => _handleMarkAsRead(notification['id'] as int),
            onDelete: () =>
                _handleDeleteNotification(notification['id'] as int),
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/chat_detail_widget.dart';
import './widgets/conversation_list_widget.dart';
import '../../services/oracle_api_service.dart';
import '../../services/oracle_websocket_service.dart';

/// Messaging & Community screen providing real-time communication
/// through WebSocket-powered chat interface optimized for mobile conversations
class MessagingCommunity extends StatefulWidget {
  const MessagingCommunity({super.key});

  @override
  State<MessagingCommunity> createState() => _MessagingCommunityState();
}

class _MessagingCommunityState extends State<MessagingCommunity>
    with SingleTickerProviderStateMixin {
  int _currentBottomNavIndex = 3; // Messages tab
  int? _selectedConversationId;
  late TabController _tabController;
  final OracleWebSocketService _wsService = OracleWebSocketService();
  bool _isLoadingConversations = false;
  List<Map<String, dynamic>> _conversations = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _initializeMessaging();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _wsService.disconnect();
    super.dispose();
  }

  Future<void> _initializeMessaging() async {
    if (OracleApiService.isAuthenticated) {
      await _loadConversations();

      try {
        final token = OracleApiService.currentUser?['token'] ?? '';
        await _wsService.connect(token);

        _wsService.messageStream?.listen((message) {
          if (message['type'] == 'chat_message') {
            _handleIncomingMessage(message);
          }
        });
      } catch (e) {
        print('WebSocket connection failed: $e');
      }
    }
  }

  Future<void> _loadConversations() async {
    setState(() => _isLoadingConversations = true);

    try {
      final conversations = await OracleApiService.fetchConversations();
      setState(() {
        _conversations = conversations;
        _isLoadingConversations = false;
      });
    } catch (e) {
      setState(() => _isLoadingConversations = false);
    }
  }

  void _handleIncomingMessage(Map<String, dynamic> message) {
    if (mounted) {
      setState(() {
        // Update conversation list with new message
      });
    }
  }

  void _handleConversationTap(int conversationId) {
    HapticFeedback.lightImpact();
    setState(() {
      _selectedConversationId = conversationId;
      _wsService.joinConversation(conversationId);
    });
  }

  void _handleBackFromChat() {
    HapticFeedback.lightImpact();
    if (_selectedConversationId != null) {
      _wsService.leaveConversation(_selectedConversationId!);
    }
    setState(() {
      _selectedConversationId = null;
    });
  }

  void _handleBottomNavTap(int index) {
    HapticFeedback.lightImpact();
    setState(() {
      _currentBottomNavIndex = index;
    });

    // Navigate to other screens based on index
    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home-feed');
        break;
      case 1:
        Navigator.pushNamed(context, '/events-travel-hub');
        break;
      case 2:
        Navigator.pushNamed(context, '/create-vibe-event');
        break;
      case 3:
        // Current screen - do nothing
        break;
      case 4:
        Navigator.pushNamed(context, '/profile-search-settings');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: _selectedConversationId == null
          ? PreferredSize(
              preferredSize: const Size.fromHeight(kToolbarHeight + 48),
              child: Column(
                children: [
                  AppBar(
                    backgroundColor: theme.scaffoldBackgroundColor,
                    elevation: 0,
                    title: Text(
                      'Messages',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    actions: [
                      IconButton(
                        icon: CustomIconWidget(
                          iconName: 'search',
                          color: theme.colorScheme.onSurface,
                          size: 24,
                        ),
                        onPressed: () {
                          HapticFeedback.lightImpact();
                          // Search functionality
                        },
                        tooltip: 'Search conversations',
                      ),
                      IconButton(
                        icon: CustomIconWidget(
                          iconName: 'add_circle_outline',
                          color: theme.colorScheme.secondary,
                          size: 24,
                        ),
                        onPressed: () {
                          HapticFeedback.lightImpact();
                          // New conversation
                        },
                        tooltip: 'New conversation',
                      ),
                      SizedBox(width: 2.w),
                    ],
                  ),
                  Container(
                    color: theme.scaffoldBackgroundColor,
                    child: TabBar(
                      controller: _tabController,
                      labelColor: theme.colorScheme.primary,
                      unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
                      indicatorColor: theme.colorScheme.secondary,
                      indicatorWeight: 3,
                      labelStyle: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                      unselectedLabelStyle: theme.textTheme.titleSmall,
                      tabs: const [
                        Tab(text: 'All'),
                        Tab(text: 'Direct'),
                        Tab(text: 'Groups'),
                      ],
                    ),
                  ),
                ],
              ),
            )
          : null,
      body: _selectedConversationId == null
          ? TabBarView(
              controller: _tabController,
              children: [
                ConversationListWidget(
                  onConversationTap: _handleConversationTap,
                  filterType: 'all',
                ),
                ConversationListWidget(
                  onConversationTap: _handleConversationTap,
                  filterType: 'direct',
                ),
                ConversationListWidget(
                  onConversationTap: _handleConversationTap,
                  filterType: 'groups',
                ),
              ],
            )
          : ChatDetailWidget(
              conversationId: _selectedConversationId!,
              onBack: _handleBackFromChat,
            ),
      bottomNavigationBar: _selectedConversationId == null
          ? CustomBottomBar(
              currentIndex: _currentBottomNavIndex,
              onTap: _handleBottomNavTap,
              badges: {3: '5'}, // 5 unread messages
            )
          : null,
    );
  }
}

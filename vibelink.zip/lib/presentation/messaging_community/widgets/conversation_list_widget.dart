import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Widget displaying list of conversations with swipe actions
class ConversationListWidget extends StatefulWidget {
  const ConversationListWidget({
    super.key,
    required this.onConversationTap,
    required this.filterType,
  });

  final Function(int) onConversationTap;
  final String filterType;

  @override
  State<ConversationListWidget> createState() => _ConversationListWidgetState();
}

class _ConversationListWidgetState extends State<ConversationListWidget> {
  bool _isRefreshing = false;
  final Set<int> _pinnedConversations = {};
  final Set<int> _mutedConversations = {};
  final Set<int> _archivedConversations = {};

  // Mock conversation data
  final List<Map<String, dynamic>> _allConversations = [
    {
      "id": 1,
      "name": "Sarah Johnson",
      "avatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1453e1878-1763300003100.png",
      "semanticLabel":
          "Profile photo of a woman with long brown hair and a warm smile, wearing a light blue blouse",
      "lastMessage": "See you at the Summer Vibes Festival! 🎉",
      "timestamp": DateTime.now().subtract(const Duration(minutes: 5)),
      "unreadCount": 2,
      "isOnline": true,
      "isGroup": false,
      "isTyping": false,
    },
    {
      "id": 2,
      "name": "Beach Party Crew",
      "avatar": "https://images.unsplash.com/photo-1639987812290-97c0c3f9fe97",
      "semanticLabel":
          "Sunset beach scene with palm trees silhouetted against orange and pink sky",
      "lastMessage": "Michael: Who's bringing the speakers?",
      "timestamp": DateTime.now().subtract(const Duration(hours: 1)),
      "unreadCount": 0,
      "isOnline": false,
      "isGroup": true,
      "isTyping": false,
      "participants": 12,
    },
    {
      "id": 3,
      "name": "Alex Martinez",
      "avatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1bc643da9-1763294856476.png",
      "semanticLabel":
          "Profile photo of a man with short dark hair and beard, wearing a casual grey t-shirt",
      "lastMessage": "Thanks for the event recommendation!",
      "timestamp": DateTime.now().subtract(const Duration(hours: 3)),
      "unreadCount": 0,
      "isOnline": true,
      "isGroup": false,
      "isTyping": true,
    },
    {
      "id": 4,
      "name": "Weekend Warriors",
      "avatar": "https://images.unsplash.com/photo-1697082799904-04d19097b64c",
      "semanticLabel":
          "Group of friends jumping joyfully on a beach at sunset with arms raised",
      "lastMessage": "Emma: Can't wait for Saturday!",
      "timestamp": DateTime.now().subtract(const Duration(hours: 5)),
      "unreadCount": 5,
      "isOnline": false,
      "isGroup": true,
      "isTyping": false,
      "participants": 8,
    },
    {
      "id": 5,
      "name": "Jessica Lee",
      "avatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_165eefc46-1763301854735.png",
      "semanticLabel":
          "Profile photo of a woman with short black hair and glasses, wearing a professional navy blazer",
      "lastMessage": "The concert tickets are confirmed ✓",
      "timestamp": DateTime.now().subtract(const Duration(days: 1)),
      "unreadCount": 0,
      "isOnline": false,
      "isGroup": false,
      "isTyping": false,
    },
    {
      "id": 6,
      "name": "Music Lovers Hub",
      "avatar": "https://images.unsplash.com/photo-1497906950454-6b0ddadf3480",
      "semanticLabel":
          "Concert crowd with raised hands silhouetted against colorful stage lights",
      "lastMessage": "David: New playlist dropped!",
      "timestamp": DateTime.now().subtract(const Duration(days: 1)),
      "unreadCount": 1,
      "isOnline": false,
      "isGroup": true,
      "isTyping": false,
      "participants": 24,
    },
    {
      "id": 7,
      "name": "Ryan Cooper",
      "avatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_123d24c77-1763293504397.png",
      "semanticLabel":
          "Profile photo of a man with blonde hair and blue eyes, wearing a white polo shirt",
      "lastMessage": "Let's catch up this weekend",
      "timestamp": DateTime.now().subtract(const Duration(days: 2)),
      "unreadCount": 0,
      "isOnline": true,
      "isGroup": false,
      "isTyping": false,
    },
    {
      "id": 8,
      "name": "Foodie Adventures",
      "avatar": "https://images.unsplash.com/photo-1706341841311-7efbbdd8d498",
      "semanticLabel":
          "Colorful array of gourmet dishes arranged on a rustic wooden table",
      "lastMessage": "Sophie: Found an amazing new restaurant!",
      "timestamp": DateTime.now().subtract(const Duration(days: 3)),
      "unreadCount": 0,
      "isOnline": false,
      "isGroup": true,
      "isTyping": false,
      "participants": 15,
    },
  ];

  List<Map<String, dynamic>> get _filteredConversations {
    List<Map<String, dynamic>> filtered = _allConversations
        .where((conv) => !_archivedConversations.contains(conv["id"] as int))
        .toList();

    if (widget.filterType == 'direct') {
      filtered = filtered.where((conv) => conv["isGroup"] == false).toList();
    } else if (widget.filterType == 'groups') {
      filtered = filtered.where((conv) => conv["isGroup"] == true).toList();
    }

    // Sort: pinned first, then by timestamp
    filtered.sort((a, b) {
      final aId = a["id"] as int;
      final bId = b["id"] as int;
      final aPinned = _pinnedConversations.contains(aId);
      final bPinned = _pinnedConversations.contains(bId);

      if (aPinned && !bPinned) return -1;
      if (!aPinned && bPinned) return 1;

      final aTime = a["timestamp"] as DateTime;
      final bTime = b["timestamp"] as DateTime;
      return bTime.compareTo(aTime);
    });

    return filtered;
  }

  Future<void> _handleRefresh() async {
    HapticFeedback.mediumImpact();
    setState(() {
      _isRefreshing = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    if (mounted) {
      setState(() {
        _isRefreshing = false;
      });
    }
  }

  void _handlePin(int conversationId) {
    HapticFeedback.lightImpact();
    setState(() {
      if (_pinnedConversations.contains(conversationId)) {
        _pinnedConversations.remove(conversationId);
      } else {
        _pinnedConversations.add(conversationId);
      }
    });
  }

  void _handleMute(int conversationId) {
    HapticFeedback.lightImpact();
    setState(() {
      if (_mutedConversations.contains(conversationId)) {
        _mutedConversations.remove(conversationId);
      } else {
        _mutedConversations.add(conversationId);
      }
    });
  }

  void _handleArchive(int conversationId) {
    HapticFeedback.lightImpact();
    setState(() {
      _archivedConversations.add(conversationId);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Conversation archived'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            setState(() {
              _archivedConversations.remove(conversationId);
            });
          },
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _handleDelete(int conversationId) {
    HapticFeedback.mediumImpact();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Conversation'),
        content: const Text(
          'Are you sure you want to delete this conversation? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _allConversations.removeWhere(
                  (conv) => conv["id"] == conversationId,
                );
              });
            },
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d';
    } else {
      return '${timestamp.day}/${timestamp.month}/${timestamp.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final conversations = _filteredConversations;

    if (conversations.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'chat_bubble_outline',
              color: theme.colorScheme.onSurfaceVariant,
              size: 64,
            ),
            SizedBox(height: 2.h),
            Text(
              'No conversations yet',
              style: theme.textTheme.titleLarge?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'Start a new conversation to connect with others',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _handleRefresh,
      child: ListView.builder(
        padding: EdgeInsets.symmetric(vertical: 1.h),
        itemCount: conversations.length,
        itemBuilder: (context, index) {
          final conversation = conversations[index];
          final conversationId = conversation["id"] as int;
          final isPinned = _pinnedConversations.contains(conversationId);
          final isMuted = _mutedConversations.contains(conversationId);

          return Slidable(
            key: ValueKey(conversationId),
            startActionPane: ActionPane(
              motion: const DrawerMotion(),
              children: [
                SlidableAction(
                  onPressed: (_) => _handlePin(conversationId),
                  backgroundColor: theme.colorScheme.secondary,
                  foregroundColor: theme.colorScheme.onSecondary,
                  icon: isPinned ? Icons.push_pin : Icons.push_pin_outlined,
                  label: isPinned ? 'Unpin' : 'Pin',
                ),
                SlidableAction(
                  onPressed: (_) => _handleMute(conversationId),
                  backgroundColor: theme.colorScheme.tertiary,
                  foregroundColor: theme.colorScheme.onTertiary,
                  icon: isMuted ? Icons.notifications : Icons.notifications_off,
                  label: isMuted ? 'Unmute' : 'Mute',
                ),
                SlidableAction(
                  onPressed: (_) => _handleArchive(conversationId),
                  backgroundColor: theme.colorScheme.onSurfaceVariant,
                  foregroundColor: theme.colorScheme.surface,
                  icon: Icons.archive,
                  label: 'Archive',
                ),
              ],
            ),
            endActionPane: ActionPane(
              motion: const DrawerMotion(),
              children: [
                SlidableAction(
                  onPressed: (_) => _handleDelete(conversationId),
                  backgroundColor: theme.colorScheme.error,
                  foregroundColor: theme.colorScheme.onError,
                  icon: Icons.delete,
                  label: 'Delete',
                ),
              ],
            ),
            child: _buildConversationItem(
              context,
              conversation,
              isPinned,
              isMuted,
            ),
          );
        },
      ),
    );
  }

  Widget _buildConversationItem(
    BuildContext context,
    Map<String, dynamic> conversation,
    bool isPinned,
    bool isMuted,
  ) {
    final theme = Theme.of(context);
    final unreadCount = conversation["unreadCount"] as int;
    final isOnline = conversation["isOnline"] as bool;
    final isGroup = conversation["isGroup"] as bool;
    final isTyping = conversation["isTyping"] as bool;

    return InkWell(
      onTap: () => widget.onConversationTap(conversation["id"] as int),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
        decoration: BoxDecoration(
          color: isPinned
              ? theme.colorScheme.secondary.withValues(alpha: 0.05)
              : Colors.transparent,
        ),
        child: Row(
          children: [
            // Avatar with online indicator
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: CustomImageWidget(
                    imageUrl: conversation["avatar"] as String,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    semanticLabel: conversation["semanticLabel"] as String,
                  ),
                ),
                if (isOnline && !isGroup)
                  Positioned(
                    right: 2,
                    bottom: 2,
                    child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: AppTheme.successLight,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: theme.scaffoldBackgroundColor,
                          width: 2,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(width: 3.w),
            // Conversation details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (isPinned) ...[
                        CustomIconWidget(
                          iconName: 'push_pin',
                          color: theme.colorScheme.secondary,
                          size: 14,
                        ),
                        SizedBox(width: 1.w),
                      ],
                      Expanded(
                        child: Text(
                          conversation["name"] as String,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: unreadCount > 0
                                ? FontWeight.w700
                                : FontWeight.w600,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (isGroup) ...[
                        SizedBox(width: 1.w),
                        CustomIconWidget(
                          iconName: 'group',
                          color: theme.colorScheme.onSurfaceVariant,
                          size: 16,
                        ),
                      ],
                    ],
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    children: [
                      if (isMuted) ...[
                        CustomIconWidget(
                          iconName: 'notifications_off',
                          color: theme.colorScheme.onSurfaceVariant,
                          size: 14,
                        ),
                        SizedBox(width: 1.w),
                      ],
                      Expanded(
                        child: isTyping
                            ? Row(
                                children: [
                                  Text(
                                    'typing',
                                    style: theme.textTheme.bodyMedium?.copyWith(
                                      color: theme.colorScheme.secondary,
                                      fontStyle: FontStyle.italic,
                                    ),
                                  ),
                                  SizedBox(width: 1.w),
                                  SizedBox(
                                    width: 20,
                                    height: 14,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: List.generate(
                                        3,
                                        (index) => Container(
                                          width: 4,
                                          height: 4,
                                          decoration: BoxDecoration(
                                            color: theme.colorScheme.secondary,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            : Text(
                                conversation["lastMessage"] as String,
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: unreadCount > 0
                                      ? theme.colorScheme.onSurface
                                      : theme.colorScheme.onSurfaceVariant,
                                  fontWeight: unreadCount > 0
                                      ? FontWeight.w500
                                      : FontWeight.w400,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(width: 2.w),
            // Timestamp and unread badge
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  _formatTimestamp(conversation["timestamp"] as DateTime),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: unreadCount > 0
                        ? theme.colorScheme.secondary
                        : theme.colorScheme.onSurfaceVariant,
                    fontWeight: unreadCount > 0
                        ? FontWeight.w600
                        : FontWeight.w400,
                  ),
                ),
                if (unreadCount > 0) ...[
                  SizedBox(height: 0.5.h),
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 2.w,
                      vertical: 0.3.h,
                    ),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.secondary,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    constraints: BoxConstraints(minWidth: 20, minHeight: 20),
                    child: Text(
                      unreadCount > 99 ? '99+' : unreadCount.toString(),
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: theme.colorScheme.onSecondary,
                        fontWeight: FontWeight.w700,
                        fontSize: 10,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
                if (isGroup && unreadCount == 0) ...[
                  SizedBox(height: 0.5.h),
                  Text(
                    '${conversation["participants"]} members',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                      fontSize: 10,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Widget displaying detailed chat conversation with messaging functionality
class ChatDetailWidget extends StatefulWidget {
  const ChatDetailWidget({
    super.key,
    required this.conversationId,
    required this.onBack,
  });

  final int conversationId;
  final VoidCallback onBack;

  @override
  State<ChatDetailWidget> createState() => _ChatDetailWidgetState();
}

class _ChatDetailWidgetState extends State<ChatDetailWidget> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _messageFocusNode = FocusNode();
  bool _isTyping = false;
  String? _replyingToMessage;

  // Mock conversation data
  final Map<int, Map<String, dynamic>> _conversationDetails = {
    1: {
      "name": "Sarah Johnson",
      "avatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1453e1878-1763300003100.png",
      "semanticLabel":
          "Profile photo of a woman with long brown hair and a warm smile, wearing a light blue blouse",
      "isOnline": true,
      "isGroup": false,
    },
    2: {
      "name": "Beach Party Crew",
      "avatar": "https://images.unsplash.com/photo-1639987812290-97c0c3f9fe97",
      "semanticLabel":
          "Sunset beach scene with palm trees silhouetted against orange and pink sky",
      "isOnline": false,
      "isGroup": true,
      "participants": 12,
    },
    3: {
      "name": "Alex Martinez",
      "avatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1bc643da9-1763294856476.png",
      "semanticLabel":
          "Profile photo of a man with short dark hair and beard, wearing a casual grey t-shirt",
      "isOnline": true,
      "isGroup": false,
    },
  };

  // Mock messages
  final List<Map<String, dynamic>> _messages = [
    {
      "id": 1,
      "senderId": 2,
      "senderName": "Sarah Johnson",
      "senderAvatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1453e1878-1763300003100.png",
      "semanticLabel":
          "Profile photo of a woman with long brown hair and a warm smile, wearing a light blue blouse",
      "message": "Hey! Are you going to the Summer Vibes Festival?",
      "timestamp": DateTime.now().subtract(const Duration(hours: 2)),
      "isMe": false,
      "status": "read",
      "type": "text",
    },
    {
      "id": 2,
      "senderId": 1,
      "senderName": "Me",
      "message": "Yes! I already got my tickets. Can't wait! 🎉",
      "timestamp": DateTime.now().subtract(
        const Duration(hours: 1, minutes: 55),
      ),
      "isMe": true,
      "status": "read",
      "type": "text",
    },
    {
      "id": 3,
      "senderId": 2,
      "senderName": "Sarah Johnson",
      "senderAvatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1453e1878-1763300003100.png",
      "semanticLabel":
          "Profile photo of a woman with long brown hair and a warm smile, wearing a light blue blouse",
      "message": "That's awesome! Want to meet up before the event?",
      "timestamp": DateTime.now().subtract(
        const Duration(hours: 1, minutes: 50),
      ),
      "isMe": false,
      "status": "read",
      "type": "text",
    },
    {
      "id": 4,
      "senderId": 1,
      "senderName": "Me",
      "message":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1c1fd5a4b-1766487207711.png",
      "semanticLabel":
          "Outdoor music festival with large crowd and colorful stage lights at sunset",
      "timestamp": DateTime.now().subtract(
        const Duration(hours: 1, minutes: 45),
      ),
      "isMe": true,
      "status": "read",
      "type": "image",
    },
    {
      "id": 5,
      "senderId": 1,
      "senderName": "Me",
      "message": "Check out the lineup! It's going to be epic!",
      "timestamp": DateTime.now().subtract(
        const Duration(hours: 1, minutes: 44),
      ),
      "isMe": true,
      "status": "read",
      "type": "text",
    },
    {
      "id": 6,
      "senderId": 2,
      "senderName": "Sarah Johnson",
      "senderAvatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1453e1878-1763300003100.png",
      "semanticLabel":
          "Profile photo of a woman with long brown hair and a warm smile, wearing a light blue blouse",
      "message": "Wow! This looks amazing! 😍",
      "timestamp": DateTime.now().subtract(
        const Duration(hours: 1, minutes: 40),
      ),
      "isMe": false,
      "status": "read",
      "type": "text",
    },
    {
      "id": 7,
      "senderId": 2,
      "senderName": "Sarah Johnson",
      "senderAvatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1453e1878-1763300003100.png",
      "semanticLabel":
          "Profile photo of a woman with long brown hair and a warm smile, wearing a light blue blouse",
      "message": "Let's meet at the main entrance at 5 PM?",
      "timestamp": DateTime.now().subtract(const Duration(minutes: 30)),
      "isMe": false,
      "status": "read",
      "type": "text",
    },
    {
      "id": 8,
      "senderId": 1,
      "senderName": "Me",
      "message": "Perfect! See you there! 👍",
      "timestamp": DateTime.now().subtract(const Duration(minutes: 5)),
      "isMe": true,
      "status": "delivered",
      "type": "text",
    },
  ];

  @override
  void initState() {
    super.initState();
    _messageController.addListener(_onMessageChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  @override
  void dispose() {
    _messageController.removeListener(_onMessageChanged);
    _messageController.dispose();
    _scrollController.dispose();
    _messageFocusNode.dispose();
    super.dispose();
  }

  void _onMessageChanged() {
    final hasText = _messageController.text.trim().isNotEmpty;
    if (hasText != _isTyping) {
      setState(() {
        _isTyping = hasText;
      });
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _handleSendMessage() {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    HapticFeedback.lightImpact();

    setState(() {
      _messages.add({
        "id": _messages.length + 1,
        "senderId": 1,
        "senderName": "Me",
        "message": message,
        "timestamp": DateTime.now(),
        "isMe": true,
        "status": "sending",
        "type": "text",
        "replyTo": _replyingToMessage,
      });
      _messageController.clear();
      _replyingToMessage = null;
    });

    _scrollToBottom();

    // Simulate message sent
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _messages.last["status"] = "sent";
        });
      }
    });
  }

  void _handleAttachment() async {
    HapticFeedback.lightImpact();

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _buildAttachmentPicker(),
    );
  }

  Widget _buildAttachmentPicker() {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          SizedBox(height: 3.h),
          Text(
            'Share',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 3.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildAttachmentOption(
                icon: 'camera_alt',
                label: 'Camera',
                color: theme.colorScheme.secondary,
                onTap: () async {
                  Navigator.pop(context);
                  final picker = ImagePicker();
                  final image = await picker.pickImage(
                    source: ImageSource.camera,
                  );
                  if (image != null) {
                    // Handle camera image
                  }
                },
              ),
              _buildAttachmentOption(
                icon: 'photo_library',
                label: 'Gallery',
                color: theme.colorScheme.tertiary,
                onTap: () async {
                  Navigator.pop(context);
                  final picker = ImagePicker();
                  final image = await picker.pickImage(
                    source: ImageSource.gallery,
                  );
                  if (image != null) {
                    // Handle gallery image
                  }
                },
              ),
              _buildAttachmentOption(
                icon: 'insert_drive_file',
                label: 'Document',
                color: AppTheme.successLight,
                onTap: () async {
                  Navigator.pop(context);
                  final result = await FilePicker.platform.pickFiles(
                    type: FileType.custom,
                    allowedExtensions: ['pdf', 'doc', 'docx', 'txt'],
                  );
                  if (result != null) {
                    // Handle document
                  }
                },
              ),
              _buildAttachmentOption(
                icon: 'location_on',
                label: 'Location',
                color: theme.colorScheme.error,
                onTap: () {
                  Navigator.pop(context);
                  // Handle location sharing
                },
              ),
            ],
          ),
          SizedBox(height: 3.h),
        ],
      ),
    );
  }

  Widget _buildAttachmentOption({
    required String icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: CustomIconWidget(iconName: icon, color: color, size: 28),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  void _handleMessageLongPress(Map<String, dynamic> message) {
    HapticFeedback.mediumImpact();

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _buildMessageActions(message),
    );
  }

  Widget _buildMessageActions(Map<String, dynamic> message) {
    final theme = Theme.of(context);
    final isMe = message["isMe"] as bool;

    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          SizedBox(height: 2.h),
          _buildActionItem(
            icon: 'reply',
            label: 'Reply',
            onTap: () {
              Navigator.pop(context);
              setState(() {
                _replyingToMessage = message["message"] as String;
              });
              _messageFocusNode.requestFocus();
            },
          ),
          _buildActionItem(
            icon: 'forward',
            label: 'Forward',
            onTap: () {
              Navigator.pop(context);
              // Handle forward
            },
          ),
          _buildActionItem(
            icon: 'content_copy',
            label: 'Copy',
            onTap: () {
              Navigator.pop(context);
              Clipboard.setData(
                ClipboardData(text: message["message"] as String),
              );
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text('Message copied')));
            },
          ),
          if (isMe)
            _buildActionItem(
              icon: 'delete',
              label: 'Delete',
              color: theme.colorScheme.error,
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _messages.removeWhere((m) => m["id"] == message["id"]);
                });
              },
            ),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildActionItem({
    required String icon,
    required String label,
    required VoidCallback onTap,
    Color? color,
  }) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 1.5.h),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: color ?? theme.colorScheme.onSurface,
              size: 24,
            ),
            SizedBox(width: 4.w),
            Text(
              label,
              style: theme.textTheme.bodyLarge?.copyWith(
                color: color ?? theme.colorScheme.onSurface,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatMessageTime(DateTime timestamp) {
    final hour = timestamp.hour.toString().padLeft(2, '0');
    final minute = timestamp.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  bool _shouldShowTimestamp(int index) {
    if (index == 0) return true;

    final currentMessage = _messages[index];
    final previousMessage = _messages[index - 1];

    final currentTime = currentMessage["timestamp"] as DateTime;
    final previousTime = previousMessage["timestamp"] as DateTime;

    return currentTime.difference(previousTime).inMinutes > 15;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final conversation = _conversationDetails[widget.conversationId];

    if (conversation == null) {
      return const Center(child: Text('Conversation not found'));
    }

    final isOnline = conversation["isOnline"] as bool;
    final isGroup = conversation["isGroup"] as bool;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: theme.scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: theme.colorScheme.onSurface,
            size: 24,
          ),
          onPressed: widget.onBack,
        ),
        title: Row(
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: CustomImageWidget(
                    imageUrl: conversation["avatar"] as String,
                    width: 40,
                    height: 40,
                    fit: BoxFit.cover,
                    semanticLabel: conversation["semanticLabel"] as String,
                  ),
                ),
                if (isOnline && !isGroup)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: AppTheme.successLight,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: theme.scaffoldBackgroundColor,
                          width: 2,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    conversation["name"] as String,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (isGroup)
                    Text(
                      '${conversation["participants"]} members',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    )
                  else if (isOnline)
                    Text(
                      'Online',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.successLight,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: CustomIconWidget(
              iconName: 'call',
              color: theme.colorScheme.onSurface,
              size: 24,
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              // Handle voice call
            },
            tooltip: 'Voice call',
          ),
          IconButton(
            icon: CustomIconWidget(
              iconName: 'videocam',
              color: theme.colorScheme.onSurface,
              size: 24,
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              // Handle video call
            },
            tooltip: 'Video call',
          ),
          SizedBox(width: 2.w),
        ],
      ),
      body: Column(
        children: [
          // Messages list
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                final showTimestamp = _shouldShowTimestamp(index);

                return Column(
                  children: [
                    if (showTimestamp) ...[
                      SizedBox(height: 2.h),
                      Center(
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 3.w,
                            vertical: 0.5.h,
                          ),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.onSurfaceVariant
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            _formatMessageTime(
                              message["timestamp"] as DateTime,
                            ),
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 2.h),
                    ],
                    _buildMessageBubble(message),
                  ],
                );
              },
            ),
          ),
          // Reply preview
          if (_replyingToMessage != null)
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                border: Border(
                  top: BorderSide(color: theme.colorScheme.outline, width: 1),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 4,
                    height: 40,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.secondary,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Replying to',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.secondary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          _replyingToMessage!,
                          style: theme.textTheme.bodySmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: CustomIconWidget(
                      iconName: 'close',
                      color: theme.colorScheme.onSurfaceVariant,
                      size: 20,
                    ),
                    onPressed: () {
                      setState(() {
                        _replyingToMessage = null;
                      });
                    },
                  ),
                ],
              ),
            ),
          // Input bar
          Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              border: Border(
                top: BorderSide(color: theme.colorScheme.outline, width: 1),
              ),
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  IconButton(
                    icon: CustomIconWidget(
                      iconName: 'attach_file',
                      color: theme.colorScheme.onSurfaceVariant,
                      size: 24,
                    ),
                    onPressed: _handleAttachment,
                    tooltip: 'Attach file',
                  ),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      focusNode: _messageFocusNode,
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: theme.colorScheme.surface,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 4.w,
                          vertical: 1.h,
                        ),
                      ),
                      maxLines: null,
                      textInputAction: TextInputAction.newline,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Container(
                    decoration: BoxDecoration(
                      color: _isTyping
                          ? theme.colorScheme.secondary
                          : theme.colorScheme.onSurfaceVariant.withValues(
                              alpha: 0.1,
                            ),
                      shape: BoxShape.circle,
                    ),
                    child: IconButton(
                      icon: CustomIconWidget(
                        iconName: 'send',
                        color: _isTyping
                            ? theme.colorScheme.onSecondary
                            : theme.colorScheme.onSurfaceVariant,
                        size: 24,
                      ),
                      onPressed: _isTyping ? _handleSendMessage : null,
                      tooltip: 'Send message',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> message) {
    final theme = Theme.of(context);
    final isMe = message["isMe"] as bool;
    final type = message["type"] as String;
    final status = message["status"] as String?;

    return GestureDetector(
      onLongPress: () => _handleMessageLongPress(message),
      child: Padding(
        padding: EdgeInsets.only(bottom: 1.h),
        child: Row(
          mainAxisAlignment: isMe
              ? MainAxisAlignment.end
              : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (!isMe) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(50),
                child: CustomImageWidget(
                  imageUrl: message["senderAvatar"] as String,
                  width: 32,
                  height: 32,
                  fit: BoxFit.cover,
                  semanticLabel: message["semanticLabel"] as String,
                ),
              ),
              SizedBox(width: 2.w),
            ],
            Flexible(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: isMe
                      ? theme.colorScheme.secondary
                      : theme.colorScheme.surface,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(16),
                    topRight: const Radius.circular(16),
                    bottomLeft: Radius.circular(isMe ? 16 : 4),
                    bottomRight: Radius.circular(isMe ? 4 : 16),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: theme.colorScheme.shadow.withValues(alpha: 0.05),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (type == 'image')
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: CustomImageWidget(
                          imageUrl: message["message"] as String,
                          width: 60.w,
                          height: 40.h,
                          fit: BoxFit.cover,
                          semanticLabel: message["semanticLabel"] as String,
                        ),
                      )
                    else
                      Text(
                        message["message"] as String,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: isMe
                              ? theme.colorScheme.onSecondary
                              : theme.colorScheme.onSurface,
                        ),
                      ),
                    SizedBox(height: 0.5.h),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _formatMessageTime(message["timestamp"] as DateTime),
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: isMe
                                ? theme.colorScheme.onSecondary.withValues(
                                    alpha: 0.7,
                                  )
                                : theme.colorScheme.onSurfaceVariant,
                            fontSize: 10,
                          ),
                        ),
                        if (isMe && status != null) ...[
                          SizedBox(width: 1.w),
                          CustomIconWidget(
                            iconName: status == 'read'
                                ? 'done_all'
                                : status == 'delivered'
                                ? 'done_all'
                                : status == 'sent'
                                ? 'done'
                                : 'schedule',
                            color: status == 'read'
                                ? theme.colorScheme.tertiary
                                : theme.colorScheme.onSecondary.withValues(
                                    alpha: 0.7,
                                  ),
                            size: 14,
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../services/oracle_api_service.dart';
import '../../review_submission/widgets/review_card_widget.dart';
import '../../review_submission/widgets/review_summary_widget.dart';

/// Profile tab displaying user information and activity
class ProfileTabWidget extends StatefulWidget {
  const ProfileTabWidget({super.key});

  @override
  State<ProfileTabWidget> createState() => _ProfileTabWidgetState();
}

class _ProfileTabWidgetState extends State<ProfileTabWidget> {
  bool _isOrganizerProfile = false;
  bool _isLoadingAnalytics = false;
  Map<String, dynamic>? _analyticsData;
  List<Map<String, dynamic>> _organizerReviews = [];
  Map<String, dynamic>? _organizerReviewStats;
  bool _isLoadingReviews = false;

  // Mock user data
  final Map<String, dynamic> _userData = {
    "name": "Sarah Johnson",
    "bio": "Adventure seeker | Music lover | Travel enthusiast 🌍✨",
    "city": "Cape Town, South Africa",
    "vibeTags": ["Music", "Travel", "Food", "Nightlife", "Art"],
    "coverPhoto":
        "https://images.unsplash.com/photo-1657522639815-b2bcc7a154ab",
    "coverSemanticLabel":
        "Scenic mountain landscape with snow-capped peaks at sunset",
    "avatar": "https://images.unsplash.com/photo-1730222168387-051038de25be",
    "avatarSemanticLabel": "Young woman with long brown hair smiling at camera",
    "postsCount": 127,
    "eventsAttended": 45,
    "followers": 2834,
    "following": 892,
  };

  // Mock organizer data
  final Map<String, dynamic> _organizerData = {
    "brandName": "VibeEvents SA",
    "description":
        "Creating unforgettable experiences across South Africa. Premium events, exclusive venues, and amazing vibes.",
    "category": "Event Management",
    "location": "Johannesburg, South Africa",
    "contactEmail": "hello@vibeevents.co.za",
    "contactPhone": "+27 82 555 1234",
    "totalBookings": 1247,
    "ticketsSold": 8934,
    "revenueCollected": "R 2,847,500",
    "activeEvents": 12,
    "coverPhoto":
        "https://images.unsplash.com/photo-1630046656824-3702aa08cd2a",
    "coverSemanticLabel":
        "Crowded outdoor music festival with stage lights and audience",
    "logo":
        "https://img.rocket.new/generatedImages/rocket_gen_img_11563857c-1767634876856.png",
    "logoSemanticLabel": "Modern event company logo with geometric design",
  };

  // Mock activity posts
  final List<Map<String, dynamic>> _activityPosts = [
    {
      "id": 1,
      "type": "post",
      "image": "https://images.unsplash.com/photo-1630636755855-d686055649af",
      "semanticLabel":
          "Acoustic guitar on wooden stage with warm stage lighting",
      "likes": 234,
      "comments": 18,
    },
    {
      "id": 2,
      "type": "event",
      "image": "https://images.unsplash.com/photo-1614603869015-1820cc8194fb",
      "semanticLabel":
          "Outdoor food festival with colorful market stalls and people",
      "eventName": "Summer Food Festival",
      "date": "15 Jan 2026",
    },
    {
      "id": 3,
      "type": "post",
      "image": "https://images.unsplash.com/photo-1668470197033-9e29921e2f3f",
      "semanticLabel": "Sunset beach scene with palm trees silhouette",
      "likes": 567,
      "comments": 42,
    },
    {
      "id": 4,
      "type": "event",
      "image": "https://images.unsplash.com/photo-1627610941497-03cd93686f0d",
      "semanticLabel": "DJ performing at nightclub with purple and blue lights",
      "eventName": "Electro Nights",
      "date": "20 Jan 2026",
    },
    {
      "id": 5,
      "type": "post",
      "image": "https://images.unsplash.com/photo-1626403884390-fbba1072ae19",
      "semanticLabel": "Gourmet burger with fries on wooden serving board",
      "likes": 892,
      "comments": 67,
    },
    {
      "id": 6,
      "type": "event",
      "image": "https://images.unsplash.com/photo-1593607358685-2aa8e6b48512",
      "semanticLabel":
          "Art gallery interior with modern paintings on white walls",
      "eventName": "Contemporary Art Expo",
      "date": "28 Jan 2026",
    },
  ];

  @override
  void initState() {
    super.initState();
    if (_isOrganizerProfile) {
      _loadOrganizerReviews();
    }
  }

  Future<void> _loadOrganizerReviews() async {
    setState(() => _isLoadingReviews = true);

    try {
      final reviews = await OracleApiService.getReviews(
        type: 'organizer',
        targetId: _organizerData['id']?.toString() ?? '1',
      );

      final stats = await OracleApiService.getReviewStats(
        type: 'organizer',
        targetId: _organizerData['id']?.toString() ?? '1',
      );

      setState(() {
        _organizerReviews = reviews;
        _organizerReviewStats = stats;
        _isLoadingReviews = false;
      });
    } catch (e) {
      setState(() => _isLoadingReviews = false);
    }
  }

  Future<void> _loadAnalytics() async {
    if (!_isOrganizerProfile) return;

    setState(() => _isLoadingAnalytics = true);

    try {
      final analytics = await OracleApiService.getOrganizerAnalytics();
      setState(() {
        _analyticsData = analytics;
        _isLoadingAnalytics = false;
      });
    } catch (e) {
      setState(() => _isLoadingAnalytics = false);
    }
  }

  void _showEditProfileModal() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildEditProfileModal(),
    );
  }

  Widget _buildEditProfileModal() {
    final theme = Theme.of(context);

    return Container(
      height: 85.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Modal header
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Cancel',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                Text(
                  'Edit Profile',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text('Profile updated successfully'),
                        backgroundColor: theme.colorScheme.secondary,
                      ),
                    );
                  },
                  child: Text(
                    'Save',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: theme.colorScheme.secondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Modal content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile photo section
                  Center(
                    child: Stack(
                      children: [
                        Container(
                          width: 25.w,
                          height: 25.w,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: theme.colorScheme.outline.withValues(
                                alpha: 0.2,
                              ),
                              width: 2,
                            ),
                          ),
                          child: ClipOval(
                            child: CustomImageWidget(
                              imageUrl: _userData["avatar"] as String,
                              width: 25.w,
                              height: 25.w,
                              fit: BoxFit.cover,
                              semanticLabel:
                                  _userData["avatarSemanticLabel"] as String,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: EdgeInsets.all(1.5.w),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.secondary,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: theme.colorScheme.surface,
                                width: 2,
                              ),
                            ),
                            child: CustomIconWidget(
                              iconName: 'camera_alt',
                              color: theme.colorScheme.onSecondary,
                              size: 4.w,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 3.h),
                  // Form fields
                  _buildTextField(
                    label: 'Name',
                    initialValue: _userData["name"] as String,
                    theme: theme,
                  ),
                  SizedBox(height: 2.h),
                  _buildTextField(
                    label: 'Bio',
                    initialValue: _userData["bio"] as String,
                    maxLines: 3,
                    theme: theme,
                  ),
                  SizedBox(height: 2.h),
                  _buildTextField(
                    label: 'City',
                    initialValue: _userData["city"] as String,
                    theme: theme,
                  ),
                  SizedBox(height: 2.h),
                  // Vibe tags section
                  Text(
                    'Vibe Tags',
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Wrap(
                    spacing: 2.w,
                    runSpacing: 1.h,
                    children: (_userData["vibeTags"] as List<dynamic>)
                        .map(
                          (tag) => Chip(
                            label: Text(tag as String),
                            deleteIcon: CustomIconWidget(
                              iconName: 'close',
                              size: 4.w,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            onDeleted: () {},
                          ),
                        )
                        .toList(),
                  ),
                  SizedBox(height: 1.h),
                  OutlinedButton.icon(
                    onPressed: () {},
                    icon: CustomIconWidget(
                      iconName: 'add',
                      size: 4.w,
                      color: theme.colorScheme.secondary,
                    ),
                    label: const Text('Add Tag'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required String initialValue,
    required ThemeData theme,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 0.5.h),
        TextFormField(
          initialValue: initialValue,
          maxLines: maxLines,
          style: theme.textTheme.bodyLarge,
          decoration: InputDecoration(
            filled: true,
            fillColor: theme.colorScheme.surface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: theme.colorScheme.secondary,
                width: 2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _buildCoverPhoto(theme),
        _buildProfileHeader(theme),
        if (_isOrganizerProfile) _buildOrganizerStats(theme),
        if (_isOrganizerProfile) _buildOrganizerReviews(theme),
        if (_isOrganizerProfile) _buildAnalyticsPreview(theme),
        if (_isOrganizerProfile) _buildRevenueChart(theme),
        if (_isOrganizerProfile) _buildTicketSalesChart(theme),
        if (_isOrganizerProfile) _buildBookingAnalytics(theme),
        if (_isOrganizerProfile) _buildCommunicationTools(theme),
        if (!_isOrganizerProfile) _buildUserStats(theme),
        _buildActivityGrid(theme),
      ],
    );
  }

  Widget _buildCoverPhoto(ThemeData theme) {
    final currentData = _isOrganizerProfile ? _organizerData : _userData;

    return Stack(
      children: [
        SizedBox(
          width: double.infinity,
          height: 25.h,
          child: CustomImageWidget(
            imageUrl: currentData["coverPhoto"] as String,
            width: double.infinity,
            height: 25.h,
            fit: BoxFit.cover,
            semanticLabel: currentData["coverSemanticLabel"] as String,
          ),
        ),
        Positioned(
          top: 2.h,
          right: 4.w,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface.withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomIconWidget(
                  iconName: 'edit',
                  size: 4.w,
                  color: theme.colorScheme.onSurface,
                ),
                SizedBox(width: 1.w),
                Text(
                  'Edit Cover',
                  style: theme.textTheme.labelMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProfileHeader(ThemeData theme) {
    return Transform.translate(
      offset: Offset(0, -8.w),
      child: Column(
        children: [
          // Avatar with camera icon
          Stack(
            children: [
              Container(
                width: 25.w,
                height: 25.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: theme.colorScheme.surface,
                    width: 4,
                  ),
                ),
                child: ClipOval(
                  child: CustomImageWidget(
                    imageUrl: _isOrganizerProfile
                        ? (_organizerData["logo"] as String)
                        : (_userData["avatar"] as String),
                    width: 25.w,
                    height: 25.w,
                    fit: BoxFit.cover,
                    semanticLabel: _isOrganizerProfile
                        ? (_organizerData["logoSemanticLabel"] as String)
                        : (_userData["avatarSemanticLabel"] as String),
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondary,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: theme.colorScheme.surface,
                      width: 2,
                    ),
                  ),
                  child: CustomIconWidget(
                    iconName: 'camera_alt',
                    color: theme.colorScheme.onSecondary,
                    size: 4.w,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          // User info
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Column(
              children: [
                Text(
                  _isOrganizerProfile
                      ? (_organizerData["brandName"] as String)
                      : (_userData["name"] as String),
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 1.h),
                if (!_isOrganizerProfile) ...[
                  Text(
                    _userData["bio"] as String,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 1.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'location_on',
                        size: 4.w,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        _userData["city"] as String,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 2.h),
                  // Vibe tags
                  Wrap(
                    spacing: 2.w,
                    runSpacing: 1.h,
                    alignment: WrapAlignment.center,
                    children: (_userData["vibeTags"] as List<dynamic>)
                        .map(
                          (tag) => Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 3.w,
                              vertical: 0.5.h,
                            ),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.secondary.withValues(
                                alpha: 0.1,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: theme.colorScheme.secondary.withValues(
                                  alpha: 0.3,
                                ),
                              ),
                            ),
                            child: Text(
                              tag as String,
                              style: theme.textTheme.labelMedium?.copyWith(
                                color: theme.colorScheme.secondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ] else ...[
                  Text(
                    _organizerData["description"] as String,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 1.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'business',
                        size: 4.w,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        _organizerData["category"] as String,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ],
                SizedBox(height: 2.h),
                // Stats row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: _isOrganizerProfile
                      ? [
                          _buildStatItem(
                            _organizerData["totalBookings"].toString(),
                            'Bookings',
                            theme,
                          ),
                          _buildStatItem(
                            _organizerData["ticketsSold"].toString(),
                            'Tickets Sold',
                            theme,
                          ),
                          _buildStatItem(
                            _organizerData["activeEvents"].toString(),
                            'Active Events',
                            theme,
                          ),
                        ]
                      : [
                          _buildStatItem(
                            _userData["postsCount"].toString(),
                            'Posts',
                            theme,
                          ),
                          _buildStatItem(
                            _userData["eventsAttended"].toString(),
                            'Events',
                            theme,
                          ),
                          _buildStatItem(
                            _userData["followers"].toString(),
                            'Followers',
                            theme,
                          ),
                          _buildStatItem(
                            _userData["following"].toString(),
                            'Following',
                            theme,
                          ),
                        ],
                ),
                SizedBox(height: 2.h),
                // Action buttons
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _showEditProfileModal,
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                        ),
                        child: const Text('Edit Profile'),
                      ),
                    ),
                    SizedBox(width: 2.w),
                    OutlinedButton(
                      onPressed: () {
                        HapticFeedback.lightImpact();
                        setState(() {
                          _isOrganizerProfile = !_isOrganizerProfile;
                        });
                      },
                      style: OutlinedButton.styleFrom(
                        padding: EdgeInsets.all(1.5.h),
                      ),
                      child: CustomIconWidget(
                        iconName: _isOrganizerProfile ? 'person' : 'business',
                        size: 5.w,
                        color: theme.colorScheme.primary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrganizerStats(ThemeData theme) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Business Stats',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              _buildStatItem(
                _organizerData['activeEvents'].toString(),
                'Active Events',
                theme,
              ),
              SizedBox(width: 4.w),
              _buildStatItem(
                _organizerData['totalBookings'].toString(),
                'Total Bookings',
                theme,
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              _buildStatItem(
                _organizerData['ticketsSold'].toString(),
                'Tickets Sold',
                theme,
              ),
              SizedBox(width: 4.w),
              _buildStatItem(
                _organizerData['revenueCollected'] as String,
                'Revenue',
                theme,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOrganizerReviews(ThemeData theme) {
    if (_isLoadingReviews) {
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        child: Center(
          child: CircularProgressIndicator(color: theme.colorScheme.secondary),
        ),
      );
    }

    final averageRating =
        (_organizerReviewStats?['average_rating'] as num?)?.toDouble() ?? 0.0;
    final totalReviews = _organizerReviewStats?['total_reviews'] as int? ?? 0;
    final ratingDistribution = Map<int, int>.from(
      _organizerReviewStats?['rating_distribution'] as Map? ?? {},
    );

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 2.h),
            child: Text(
              'Organizer Reviews',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          ReviewSummaryWidget(
            averageRating: averageRating,
            totalReviews: totalReviews,
            ratingDistribution: ratingDistribution,
            onWriteReview: () async {
              final result = await Navigator.pushNamed(
                context,
                AppRoutes.reviewSubmission,
                arguments: {
                  'type': 'organizer',
                  'targetId': _organizerData['id']?.toString() ?? '1',
                  'targetName': _organizerData['brandName'] as String,
                },
              );

              if (result == true) {
                _loadOrganizerReviews();
              }
            },
          ),
          if (_organizerReviews.isNotEmpty) SizedBox(height: 2.h),
          if (_organizerReviews.isNotEmpty)
            ..._organizerReviews
                .take(3)
                .map((review) => ReviewCardWidget(review: review)),
          if (_organizerReviews.length > 3) SizedBox(height: 1.h),
          if (_organizerReviews.length > 3)
            Center(
              child: TextButton(
                onPressed: () {
                  // Navigate to full reviews screen
                },
                child: Text(
                  'View all ${_organizerReviews.length} reviews',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.secondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAnalyticsPreview(ThemeData theme) {
    final stats =
        _analyticsData?['key_metrics'] ??
        {
          'total_revenue': 'R 284,450',
          'total_tickets_sold': 3247,
          'total_events': 18,
          'avg_ticket_price': 'R 876',
        };

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Quick Stats',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton(
                onPressed: () {
                  HapticFeedback.lightImpact();
                  Navigator.pushNamed(context, AppRoutes.organizerAnalytics);
                },
                child: Text(
                  'View Details',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildQuickStatCard(
                  theme,
                  'Revenue',
                  stats['total_revenue'].toString(),
                  Icons.attach_money,
                  AppTheme.successLight,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _buildQuickStatCard(
                  theme,
                  'Tickets',
                  stats['total_tickets_sold'].toString(),
                  Icons.confirmation_number,
                  AppTheme.secondaryLight,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.w),
          Row(
            children: [
              Expanded(
                child: _buildQuickStatCard(
                  theme,
                  'Events',
                  stats['total_events'].toString(),
                  Icons.event,
                  AppTheme.accentLight,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _buildQuickStatCard(
                  theme,
                  'Avg Price',
                  stats['avg_ticket_price'].toString(),
                  Icons.local_offer,
                  const Color(0xFF8B5CF6),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStatCard(
    ThemeData theme,
    String label,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRevenueChart(ThemeData theme) {
    if (_isLoadingAnalytics) {
      return Center(
        child: Padding(
          padding: EdgeInsets.all(4.w),
          child: CircularProgressIndicator(color: theme.colorScheme.secondary),
        ),
      );
    }

    final revenueData =
        _analyticsData?['revenue_by_month'] ??
        [
          {'month': 'Jan', 'revenue': 45000},
          {'month': 'Feb', 'revenue': 52000},
          {'month': 'Mar', 'revenue': 48000},
          {'month': 'Apr', 'revenue': 67000},
          {'month': 'May', 'revenue': 71000},
          {'month': 'Jun', 'revenue': 89000},
        ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Revenue Overview',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          SizedBox(
            height: 25.h,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 20000,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: theme.colorScheme.outline.withValues(alpha: 0.2),
                      strokeWidth: 1,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          'R${(value / 1000).toInt()}k',
                          style: theme.textTheme.labelSmall,
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= 0 &&
                            value.toInt() < revenueData.length) {
                          return Text(
                            revenueData[value.toInt()]['month'],
                            style: theme.textTheme.labelSmall,
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: List.generate(
                      revenueData.length,
                      (index) => FlSpot(
                        index.toDouble(),
                        revenueData[index]['revenue'].toDouble(),
                      ),
                    ),
                    isCurved: true,
                    color: theme.colorScheme.secondary,
                    barWidth: 3,
                    dotData: const FlDotData(show: true),
                    belowBarData: BarAreaData(
                      show: true,
                      color: theme.colorScheme.secondary.withValues(alpha: 0.1),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTicketSalesChart(ThemeData theme) {
    final salesData =
        _analyticsData?['ticket_sales_by_event'] ??
        [
          {'event': 'Summer Fest', 'sold': 450, 'total': 500},
          {'event': 'Jazz Night', 'sold': 280, 'total': 300},
          {'event': 'Food Fair', 'sold': 890, 'total': 1000},
          {'event': 'Art Expo', 'sold': 320, 'total': 400},
        ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ticket Sales Trends',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          SizedBox(
            height: 25.h,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: 1000,
                barTouchData: BarTouchData(enabled: true),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: theme.textTheme.labelSmall,
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= 0 &&
                            value.toInt() < salesData.length) {
                          return Padding(
                            padding: EdgeInsets.only(top: 1.h),
                            child: Text(
                              salesData[value.toInt()]['event']
                                  .toString()
                                  .split(' ')[0],
                              style: theme.textTheme.labelSmall,
                            ),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                gridData: FlGridData(show: true, drawVerticalLine: false),
                borderData: FlBorderData(show: false),
                barGroups: List.generate(
                  salesData.length,
                  (index) => BarChartGroupData(
                    x: index,
                    barRods: [
                      BarChartRodData(
                        toY: salesData[index]['sold'].toDouble(),
                        color: theme.colorScheme.secondary,
                        width: 20,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(4),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBookingAnalytics(ThemeData theme) {
    final bookingStats =
        _analyticsData?['booking_stats'] ??
        {
          'total_bookings': 1247,
          'pending': 23,
          'confirmed': 1189,
          'cancelled': 35,
          'avg_booking_value': 'R 2,284',
        };

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Booking Analytics',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  'Total',
                  bookingStats['total_bookings'].toString(),
                  Icons.confirmation_number,
                  theme.colorScheme.secondary,
                  theme,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _buildStatCard(
                  'Confirmed',
                  bookingStats['confirmed'].toString(),
                  Icons.check_circle,
                  Colors.green,
                  theme,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  'Pending',
                  bookingStats['pending'].toString(),
                  Icons.pending,
                  Colors.orange,
                  theme,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _buildStatCard(
                  'Avg Value',
                  bookingStats['avg_booking_value'],
                  Icons.attach_money,
                  theme.colorScheme.tertiary,
                  theme,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    String label,
    String value,
    IconData icon,
    Color color,
    ThemeData theme,
  ) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 6.w),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCommunicationTools(ThemeData theme) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Customer Communication',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          ListTile(
            leading: Icon(Icons.message, color: theme.colorScheme.secondary),
            title: const Text('Message All Attendees'),
            subtitle: const Text('Send updates to all ticket holders'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => _showMessageAttendeesDialog(theme),
          ),
          Divider(color: theme.colorScheme.outline.withValues(alpha: 0.2)),
          ListTile(
            leading: Icon(Icons.email, color: theme.colorScheme.secondary),
            title: const Text('Email Campaign'),
            subtitle: const Text('Create targeted email campaigns'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {},
          ),
          Divider(color: theme.colorScheme.outline.withValues(alpha: 0.2)),
          ListTile(
            leading: Icon(
              Icons.notifications,
              color: theme.colorScheme.secondary,
            ),
            title: const Text('Push Notifications'),
            subtitle: const Text('Send instant notifications'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {},
          ),
        ],
      ),
    );
  }

  void _showMessageAttendeesDialog(ThemeData theme) {
    final messageController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Message Attendees'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: messageController,
              decoration: const InputDecoration(
                labelText: 'Message',
                hintText: 'Enter your message...',
              ),
              maxLines: 4,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (messageController.text.isNotEmpty) {
                Navigator.pop(context);
                try {
                  await OracleApiService.messageAttendees(
                    eventId: 1,
                    message: messageController.text,
                  );
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Message sent successfully!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Failed to send: ${e.toString()}'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              }
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  Widget _buildUserStats(ThemeData theme) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'User Stats',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  _userData["postsCount"].toString(),
                  'Posts',
                  theme,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _buildStatItem(
                  _userData["eventsAttended"].toString(),
                  'Events',
                  theme,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  _userData["followers"].toString(),
                  'Followers',
                  theme,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _buildStatItem(
                  _userData["following"].toString(),
                  'Following',
                  theme,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActivityGrid(ThemeData theme) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _isOrganizerProfile ? 'Hosted Events' : 'Activity',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 1.w,
              mainAxisSpacing: 1.w,
              childAspectRatio: 1,
            ),
            itemCount: _activityPosts.length,
            itemBuilder: (context, index) {
              final post = _activityPosts[index];
              return GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                },
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: CustomImageWidget(
                        imageUrl: post["image"] as String,
                        width: double.infinity,
                        height: double.infinity,
                        fit: BoxFit.cover,
                        semanticLabel: post["semanticLabel"] as String,
                      ),
                    ),
                    if (post["type"] == "event")
                      Positioned(
                        top: 1.w,
                        right: 1.w,
                        child: Container(
                          padding: EdgeInsets.all(1.w),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.secondary,
                            shape: BoxShape.circle,
                          ),
                          child: CustomIconWidget(
                            iconName: 'event',
                            size: 3.w,
                            color: theme.colorScheme.onSecondary,
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildStatItem(String value, String label, ThemeData theme) {
    return Column(
      children: [
        Text(
          value,
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Search tab for discovering users, events, and vibes
class SearchTabWidget extends StatefulWidget {
  const SearchTabWidget({super.key});

  @override
  State<SearchTabWidget> createState() => _SearchTabWidgetState();
}

class _SearchTabWidgetState extends State<SearchTabWidget> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedFilter = 'All';
  bool _isSearching = false;

  // Mock recent searches
  final List<String> _recentSearches = [
    'Summer Music Festival',
    'Cape Town Events',
    'Sarah Johnson',
    'Nightlife',
  ];

  // Mock trending hashtags
  final List<Map<String, dynamic>> _trendingHashtags = [
    {"tag": "#SummerVibes", "count": "12.5K posts"},
    {"tag": "#CapeTownNights", "count": "8.9K posts"},
    {"tag": "#FoodFestival", "count": "6.2K posts"},
    {"tag": "#LiveMusic", "count": "15.3K posts"},
    {"tag": "#TravelSA", "count": "9.7K posts"},
  ];

  // Mock search results
  final List<Map<String, dynamic>> _searchResults = [
    {
      "type": "user",
      "name": "Sarah Johnson",
      "username": "@sarahjohnson",
      "avatar": "https://images.unsplash.com/photo-1730222168387-051038de25be",
      "semanticLabel": "Young woman with long brown hair smiling at camera",
      "followers": "2.8K followers",
      "isVerified": true,
    },
    {
      "type": "event",
      "title": "Summer Music Festival 2026",
      "date": "15 Jan 2026",
      "location": "Cape Town Stadium",
      "image": "https://images.unsplash.com/photo-1619229665486-19f7ee2987a5",
      "semanticLabel":
          "Outdoor music festival with large crowd and stage lights",
      "price": "R 250",
      "attendees": "1.2K attending",
    },
    {
      "type": "user",
      "name": "VibeEvents SA",
      "username": "@vibeevents",
      "avatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_11563857c-1767634876856.png",
      "semanticLabel": "Modern event company logo with geometric design",
      "followers": "15.3K followers",
      "isVerified": true,
    },
    {
      "type": "vibe",
      "author": "Mike Chen",
      "authorAvatar":
          "https://img.rocket.new/generatedImages/rocket_gen_img_1fd271143-1763293008274.png",
      "authorSemanticLabel": "Young man with short dark hair in casual attire",
      "content":
          "Amazing night at the rooftop bar! The sunset views were incredible 🌅",
      "image": "https://images.unsplash.com/photo-1707634774682-a18ad7f3f3ec",
      "imageSemanticLabel": "Rooftop bar at sunset with city skyline view",
      "likes": "234",
      "comments": "18",
      "timestamp": "2 hours ago",
    },
    {
      "type": "event",
      "title": "Food & Wine Pairing Experience",
      "date": "20 Jan 2026",
      "location": "Constantia Wine Estate",
      "image": "https://images.unsplash.com/photo-1734360618982-0e40eb2f942d",
      "semanticLabel": "Elegant wine glasses and gourmet food on wooden table",
      "price": "R 450",
      "attendees": "45 attending",
    },
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _performSearch(String query) {
    if (query.isEmpty) {
      setState(() => _isSearching = false);
      return;
    }

    HapticFeedback.lightImpact();
    setState(() => _isSearching = true);
  }

  void _clearSearch() {
    HapticFeedback.lightImpact();
    _searchController.clear();
    setState(() => _isSearching = false);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      children: [
        // Search bar
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            border: Border(
              bottom: BorderSide(
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
              ),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: _performSearch,
                  style: theme.textTheme.bodyLarge,
                  decoration: InputDecoration(
                    hintText: 'Search users, events, vibes...',
                    prefixIcon: Padding(
                      padding: EdgeInsets.all(3.w),
                      child: CustomIconWidget(
                        iconName: 'search',
                        size: 5.w,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: CustomIconWidget(
                              iconName: 'close',
                              size: 5.w,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            onPressed: _clearSearch,
                          )
                        : null,
                    filled: true,
                    fillColor: theme.colorScheme.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: theme.colorScheme.outline.withValues(alpha: 0.2),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: theme.colorScheme.outline.withValues(alpha: 0.2),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: theme.colorScheme.secondary,
                        width: 2,
                      ),
                    ),
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 4.w,
                      vertical: 1.5.h,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              IconButton(
                icon: CustomIconWidget(
                  iconName: 'mic',
                  size: 6.w,
                  color: theme.colorScheme.secondary,
                ),
                onPressed: () {
                  HapticFeedback.lightImpact();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Voice search activated'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
        // Filter chips
        if (_isSearching)
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              border: Border(
                bottom: BorderSide(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                ),
              ),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: ['All', 'Users', 'Events', 'Vibes']
                    .map(
                      (filter) => Padding(
                        padding: EdgeInsets.only(right: 2.w),
                        child: FilterChip(
                          label: Text(filter),
                          selected: _selectedFilter == filter,
                          onSelected: (selected) {
                            HapticFeedback.lightImpact();
                            setState(() => _selectedFilter = filter);
                          },
                          selectedColor: theme.colorScheme.secondary.withValues(
                            alpha: 0.2,
                          ),
                          checkmarkColor: theme.colorScheme.secondary,
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
          ),
        // Content area
        Expanded(
          child: _isSearching
              ? _buildSearchResults(theme)
              : _buildDefaultContent(theme),
        ),
      ],
    );
  }

  Widget _buildDefaultContent(ThemeData theme) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Recent searches
          if (_recentSearches.isNotEmpty) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Recent Searches',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    HapticFeedback.lightImpact();
                  },
                  child: Text(
                    'Clear All',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.secondary,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.h),
            Wrap(
              spacing: 2.w,
              runSpacing: 1.h,
              children: _recentSearches
                  .map(
                    (search) => Chip(
                      label: Text(search),
                      deleteIcon: CustomIconWidget(
                        iconName: 'close',
                        size: 4.w,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      onDeleted: () {
                        HapticFeedback.lightImpact();
                      },
                    ),
                  )
                  .toList(),
            ),
            SizedBox(height: 3.h),
          ],
          // Trending hashtags
          Text(
            'Trending Now',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _trendingHashtags.length,
            separatorBuilder: (context, index) => SizedBox(height: 1.h),
            itemBuilder: (context, index) {
              final hashtag = _trendingHashtags[index];
              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  width: 12.w,
                  height: 12.w,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: 'tag',
                      size: 6.w,
                      color: theme.colorScheme.secondary,
                    ),
                  ),
                ),
                title: Text(
                  hashtag["tag"] as String,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                subtitle: Text(
                  hashtag["count"] as String,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                trailing: CustomIconWidget(
                  iconName: 'chevron_right',
                  size: 5.w,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
                onTap: () {
                  HapticFeedback.lightImpact();
                  _searchController.text = hashtag["tag"] as String;
                  _performSearch(hashtag["tag"] as String);
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSearchResults(ThemeData theme) {
    final filteredResults = _selectedFilter == 'All'
        ? _searchResults
        : _searchResults
              .where(
                (result) =>
                    result["type"] ==
                    _selectedFilter.toLowerCase().replaceAll('s', ''),
              )
              .toList();

    return ListView.separated(
      padding: EdgeInsets.all(4.w),
      itemCount: filteredResults.length,
      separatorBuilder: (context, index) => SizedBox(height: 2.h),
      itemBuilder: (context, index) {
        final result = filteredResults[index];
        final type = result["type"] as String;

        switch (type) {
          case 'user':
            return _buildUserResult(result, theme);
          case 'event':
            return _buildEventResult(result, theme);
          case 'vibe':
            return _buildVibeResult(result, theme);
          default:
            return const SizedBox.shrink();
        }
      },
    );
  }

  Widget _buildUserResult(Map<String, dynamic> user, ThemeData theme) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Stack(
        children: [
          Container(
            width: 14.w,
            height: 14.w,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
                width: 2,
              ),
            ),
            child: ClipOval(
              child: CustomImageWidget(
                imageUrl: user["avatar"] as String,
                width: 14.w,
                height: 14.w,
                fit: BoxFit.cover,
                semanticLabel: user["semanticLabel"] as String,
              ),
            ),
          ),
          if (user["isVerified"] == true)
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                padding: EdgeInsets.all(0.5.w),
                decoration: BoxDecoration(
                  color: theme.colorScheme.secondary,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: theme.colorScheme.surface,
                    width: 2,
                  ),
                ),
                child: CustomIconWidget(
                  iconName: 'verified',
                  size: 3.w,
                  color: theme.colorScheme.onSecondary,
                ),
              ),
            ),
        ],
      ),
      title: Text(
        user["name"] as String,
        style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            user["username"] as String,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            user["followers"] as String,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
      trailing: OutlinedButton(
        onPressed: () {
          HapticFeedback.lightImpact();
        },
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        ),
        child: const Text('Follow'),
      ),
      onTap: () {
        HapticFeedback.lightImpact();
      },
    );
  }

  Widget _buildEventResult(Map<String, dynamic> event, ThemeData theme) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
      },
      child: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: theme.colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(16),
              ),
              child: CustomImageWidget(
                imageUrl: event["image"] as String,
                width: double.infinity,
                height: 20.h,
                fit: BoxFit.cover,
                semanticLabel: event["semanticLabel"] as String,
              ),
            ),
            Padding(
              padding: EdgeInsets.all(3.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event["title"] as String,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'calendar_today',
                        size: 4.w,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        event["date"] as String,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      SizedBox(width: 3.w),
                      CustomIconWidget(
                        iconName: 'location_on',
                        size: 4.w,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      SizedBox(width: 1.w),
                      Expanded(
                        child: Text(
                          event["location"] as String,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 1.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        event["price"] as String,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: theme.colorScheme.secondary,
                        ),
                      ),
                      Text(
                        event["attendees"] as String,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVibeResult(Map<String, dynamic> vibe, ThemeData theme) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 10.w,
                height: 10.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  ),
                ),
                child: ClipOval(
                  child: CustomImageWidget(
                    imageUrl: vibe["authorAvatar"] as String,
                    width: 10.w,
                    height: 10.w,
                    fit: BoxFit.cover,
                    semanticLabel: vibe["authorSemanticLabel"] as String,
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      vibe["author"] as String,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      vibe["timestamp"] as String,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(vibe["content"] as String, style: theme.textTheme.bodyMedium),
          if (vibe["image"] != null) ...[
            SizedBox(height: 1.h),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomImageWidget(
                imageUrl: vibe["image"] as String,
                width: double.infinity,
                height: 25.h,
                fit: BoxFit.cover,
                semanticLabel: vibe["imageSemanticLabel"] as String,
              ),
            ),
          ],
          SizedBox(height: 1.h),
          Row(
            children: [
              CustomIconWidget(
                iconName: 'favorite_border',
                size: 5.w,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              SizedBox(width: 1.w),
              Text(
                vibe["likes"] as String,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              SizedBox(width: 4.w),
              CustomIconWidget(
                iconName: 'chat_bubble_outline',
                size: 5.w,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              SizedBox(width: 1.w),
              Text(
                vibe["comments"] as String,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

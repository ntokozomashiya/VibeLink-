import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/analytics_service.dart';
import '../../services/oracle_api_service.dart';
import '../../widgets/payment_form_widget.dart';
import '../../widgets/verified_badge_widget.dart';
import '../events_travel_hub/widgets/flight_search_widget.dart';

class EventDetailScreen extends StatefulWidget {
  const EventDetailScreen({super.key});

  @override
  State<EventDetailScreen> createState() => _EventDetailScreenState();
}

class _EventDetailScreenState extends State<EventDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  Map<String, dynamic>? _event;
  bool _isLoading = true;
  bool _isGoing = false;
  int _attendeeCount = 0;
  List<Map<String, dynamic>> _attendees = [];
  Map<String, dynamic>? _travelBundle;
  bool _isLoadingTravel = false;
  List<Map<String, dynamic>> _reviews = [];
  Map<String, dynamic>? _reviewStats;
  bool _isLoadingReviews = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args != null && args is Map<String, dynamic>) {
      _event = args;
      _loadEventDetails();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadEventDetails() async {
    if (_event == null) return;

    setState(() => _isLoading = true);

    try {
      // Track event view
      await AnalyticsService.trackEventView(
        eventId: _event!['id'].toString(),
        eventTitle: _event!['title'] as String,
      );

      // Load attendee count
      final count = await OracleApiService.getEventAttendeeCount(
        _event!['id'].toString(),
      );

      // Load attendees list
      final attendees = await OracleApiService.getEventAttendees(
        _event!['id'].toString(),
      );

      // Load reviews
      await _loadReviews();

      setState(() {
        _attendeeCount = count;
        _attendees = attendees;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load event details: $e')),
        );
      }
    }
  }

  Future<void> _loadReviews() async {
    if (_event == null) return;

    setState(() => _isLoadingReviews = true);

    try {
      final reviews = await OracleApiService.getReviews(
        type: 'event',
        targetId: _event!['id'].toString(),
      );

      final stats = await OracleApiService.getReviewStats(
        type: 'event',
        targetId: _event!['id'].toString(),
      );

      setState(() {
        _reviews = reviews;
        _reviewStats = stats;
        _isLoadingReviews = false;
      });
    } catch (e) {
      setState(() => _isLoadingReviews = false);
    }
  }

  Future<void> _toggleGoing() async {
    if (_event == null) return;

    final newState = !_isGoing;

    try {
      await OracleApiService.markEventGoing(
        eventId: _event!['id'].toString(),
        isGoing: newState,
      );

      // Track RSVP
      await AnalyticsService.trackRSVP(
        eventId: _event!['id'].toString(),
        eventTitle: _event!['title'] as String,
        isGoing: newState,
      );

      setState(() {
        _isGoing = newState;
        _attendeeCount += newState ? 1 : -1;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              newState ? 'You\'re going to this event!' : 'RSVP removed',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update RSVP: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _purchaseTicket() async {
    if (_event == null) return;

    final price = double.parse(
      (_event!['price'] as String).replaceAll('R ', '').replaceAll(',', ''),
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => PaymentFormWidget(
        amount: price,
        description: 'Ticket for ${_event!['title']}',
        onPaymentSuccess: (paymentIntentId) async {
          try {
            await OracleApiService.bookEvent(
              eventId: _event!['id'] as int,
              quantity: 1,
              paymentIntentId: paymentIntentId,
            );

            // Track ticket purchase
            await AnalyticsService.trackTicketPurchase(
              eventId: _event!['id'].toString(),
              eventTitle: _event!['title'] as String,
              quantity: 1,
              amount: price,
            );

            if (mounted) {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Ticket purchased successfully!')),
              );
            }
          } catch (e) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Booking failed: ${e.toString()}'),
                  backgroundColor: Colors.red,
                ),
              );
            }
          }
        },
      ),
    );
  }

  Future<void> _loadTravelBundle() async {
    if (_event == null || _isLoadingTravel) return;

    setState(() => _isLoadingTravel = true);

    try {
      final bundle = await OracleApiService.getEventTravelBundle(
        _event!['id'] as int,
      );

      setState(() {
        _travelBundle = bundle;
        _isLoadingTravel = false;
      });
    } catch (e) {
      setState(() => _isLoadingTravel = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_event == null) {
      return Scaffold(
        appBar: AppBar(backgroundColor: theme.colorScheme.surface),
        body: Center(
          child: Text('Event not found', style: theme.textTheme.bodyLarge),
        ),
      );
    }

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: CustomScrollView(
        slivers: [
          _buildAppBar(theme),
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildEventHeader(theme),
                _buildActionButtons(theme),
                _buildTabBar(theme),
              ],
            ),
          ),
          SliverFillRemaining(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildOverviewTab(theme),
                _buildTicketsTab(theme),
                _buildTravelTab(theme),
                _buildAttendeesTab(theme),
                _buildReviewsTab(theme),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar(ThemeData theme) {
    final isBoosted = _event!['is_boosted'] ?? false;

    return SliverAppBar(
      expandedHeight: 300,
      pinned: true,
      backgroundColor: theme.colorScheme.surface,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface.withValues(alpha: 0.9),
            shape: BoxShape.circle,
          ),
          child: CustomIconWidget(
            iconName: 'arrow_back',
            size: 20,
            color: theme.colorScheme.onSurface,
          ),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface.withValues(alpha: 0.9),
              shape: BoxShape.circle,
            ),
            child: CustomIconWidget(
              iconName: 'share',
              size: 20,
              color: theme.colorScheme.onSurface,
            ),
          ),
          onPressed: () {},
        ),
        IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface.withValues(alpha: 0.9),
              shape: BoxShape.circle,
            ),
            child: CustomIconWidget(
              iconName: 'favorite_border',
              size: 20,
              color: theme.colorScheme.onSurface,
            ),
          ),
          onPressed: () {},
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Stack(
          fit: StackFit.expand,
          children: [
            CustomImageWidget(
              imageUrl: _event!['image'] as String,
              fit: BoxFit.cover,
              semanticLabel: _event!['semanticLabel'] as String,
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    theme.colorScheme.surface.withValues(alpha: 0.8),
                  ],
                ),
              ),
            ),
            if (isBoosted)
              Positioned(
                top: 60,
                left: 16,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.tertiary,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.star,
                        size: 16,
                        color: theme.colorScheme.onTertiary,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'FEATURED EVENT',
                        style: theme.textTheme.labelSmall?.copyWith(
                          color: theme.colorScheme.onTertiary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEventHeader(ThemeData theme) {
    final organizer = _event!['organizer'] as Map<String, dynamic>;
    final isVerified = _event!['is_verified'] ?? false;

    return Padding(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  _event!['title'] as String,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              if (isVerified) VerifiedBadgeWidget(isVerified: isVerified),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: CustomImageWidget(
                  imageUrl: organizer['avatar'] as String,
                  width: 40,
                  height: 40,
                  fit: BoxFit.cover,
                  semanticLabel: organizer['avatarLabel'] as String,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Organized by',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    Text(
                      organizer['name'] as String,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          _buildInfoRow(
            theme,
            'calendar_today',
            _formatDate(_event!['date'] as String),
          ),
          SizedBox(height: 1.h),
          _buildInfoRow(theme, 'location_on', _event!['city'] as String),
          SizedBox(height: 1.h),
          _buildInfoRow(theme, 'people', '$_attendeeCount people going'),
        ],
      ),
    );
  }

  Widget _buildInfoRow(ThemeData theme, String icon, String text) {
    return Row(
      children: [
        CustomIconWidget(
          iconName: icon,
          size: 20,
          color: theme.colorScheme.secondary,
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
      ],
    );
  }

  Widget _buildActionButtons(ThemeData theme) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _toggleGoing,
              icon: CustomIconWidget(
                iconName: _isGoing ? 'check_circle' : 'check_circle_outline',
                size: 20,
                color: theme.colorScheme.onSecondary,
              ),
              label: Text(_isGoing ? 'Going' : 'Mark Going'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _isGoing
                    ? theme.colorScheme.secondary
                    : theme.colorScheme.outline,
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _purchaseTicket,
              icon: CustomIconWidget(
                iconName: 'confirmation_number',
                size: 20,
                color: theme.colorScheme.onSecondary,
              ),
              label: Text('Buy Ticket'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar(ThemeData theme) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.h),
      child: TabBar(
        controller: _tabController,
        labelColor: theme.colorScheme.secondary,
        unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
        indicatorColor: theme.colorScheme.secondary,
        tabs: const [
          Tab(text: 'Overview'),
          Tab(text: 'Tickets'),
          Tab(text: 'Travel'),
          Tab(text: 'Attendees'),
          Tab(text: 'Reviews'),
        ],
      ),
    );
  }

  Widget _buildOverviewTab(ThemeData theme) {
    return ListView(
      padding: EdgeInsets.all(4.w),
      children: [
        Text(
          'About Event',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          _event!['description'] as String,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
            height: 1.5,
          ),
        ),
        SizedBox(height: 3.h),
        Text(
          'Event Details',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        _buildDetailCard(theme, 'Category', _event!['vibeType'] as String),
        _buildDetailCard(theme, 'Price', _event!['price'] as String),
        _buildDetailCard(
          theme,
          'Capacity',
          '${_event!['attendees']}/${_event!['capacity']} attendees',
        ),
      ],
    );
  }

  Widget _buildDetailCard(ThemeData theme, String label, String value) {
    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTicketsTab(ThemeData theme) {
    final price = _event!['price'] as String;

    return ListView(
      padding: EdgeInsets.all(4.w),
      children: [
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: theme.colorScheme.secondaryContainer,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'General Admission',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 1.h),
              Text(
                price,
                style: theme.textTheme.headlineSmall?.copyWith(
                  color: theme.colorScheme.secondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 2.h),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _purchaseTicket,
                  child: const Text('Purchase Ticket'),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 2.h),
        Text(
          'What\'s Included',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        _buildIncludedItem(theme, 'Event admission'),
        _buildIncludedItem(theme, 'Digital ticket with QR code'),
        _buildIncludedItem(theme, 'Access to event updates'),
      ],
    );
  }

  Widget _buildIncludedItem(ThemeData theme, String text) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.5.h),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'check_circle',
            size: 20,
            color: theme.colorScheme.secondary,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
        ],
      ),
    );
  }

  Widget _buildTravelTab(ThemeData theme) {
    if (_travelBundle == null && !_isLoadingTravel) {
      _loadTravelBundle();
    }

    return ListView(
      padding: EdgeInsets.all(4.w),
      children: [
        Text(
          'Travel & Accommodation',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),
        _buildTravelOption(
          theme,
          'Flights',
          'Find flights to ${_event!['city']}',
          'flight',
          () => _showFlightSearch(),
        ),
        _buildTravelOption(
          theme,
          'Accommodation',
          'Book hotels near venue',
          'hotel',
          () {},
        ),
        _buildTravelOption(
          theme,
          'Rides',
          'Get Uber/Bolt estimates',
          'directions_car',
          () {},
        ),
      ],
    );
  }

  Widget _buildTravelOption(
    ThemeData theme,
    String title,
    String subtitle,
    String icon,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: 2.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: theme.colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(12),
              ),
              child: CustomIconWidget(
                iconName: icon,
                size: 24,
                color: theme.colorScheme.secondary,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            CustomIconWidget(
              iconName: 'arrow_forward_ios',
              size: 16,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ],
        ),
      ),
    );
  }

  void _showFlightSearch() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FlightSearchWidget(
        onSearch: (from, to, date) {
          // Handle flight search
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Searching flights from $from to $to')),
          );
        },
      ),
    );
  }

  Widget _buildAttendeesTab(ThemeData theme) {
    return ListView(
      padding: EdgeInsets.all(4.w),
      children: [
        Text(
          '$_attendeeCount people going',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),
        if (_attendees.isEmpty)
          Center(
            child: Padding(
              padding: EdgeInsets.all(4.h),
              child: Text(
                'No attendees yet. Be the first!',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          )
        else
          ..._attendees.map((attendee) => _buildAttendeeCard(theme, attendee)),
      ],
    );
  }

  Widget _buildAttendeeCard(ThemeData theme, Map<String, dynamic> attendee) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: CustomImageWidget(
              imageUrl: attendee['avatar'] as String,
              width: 40,
              height: 40,
              fit: BoxFit.cover,
              semanticLabel: attendee['name'] as String,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              attendee['name'] as String,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewsTab(ThemeData theme) {
    return ListView(
      padding: EdgeInsets.all(4.w),
      children: [
        Text(
          'Reviews',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        if (_isLoadingReviews)
          Center(child: CircularProgressIndicator())
        else
          _buildReviewStats(theme),
        SizedBox(height: 2.h),
        if (_reviews.isEmpty)
          Center(
            child: Padding(
              padding: EdgeInsets.all(4.h),
              child: Text(
                'No reviews yet. Be the first!',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          )
        else
          ..._reviews.map((review) => _buildReviewCard(theme, review)),
      ],
    );
  }

  Widget _buildReviewStats(ThemeData theme) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Text(
            'Average Rating',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            _reviewStats?['averageRating']?.toString() ?? 'N/A',
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 16),
          Text(
            'Total Reviews',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            _reviewStats?['totalReviews']?.toString() ?? '0',
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewCard(ThemeData theme, Map<String, dynamic> review) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: CustomImageWidget(
              imageUrl: review['avatar'] as String,
              width: 40,
              height: 40,
              fit: BoxFit.cover,
              semanticLabel: review['name'] as String,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  review['name'] as String,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  review['rating'] as String,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                Text(
                  review['text'] as String,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr);
      final months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
      return '${months[date.month - 1]} ${date.day}, ${date.year}';
    } catch (e) {
      return dateStr;
    }
  }
}

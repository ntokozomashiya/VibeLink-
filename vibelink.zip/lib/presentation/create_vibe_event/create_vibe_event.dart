import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/event_creation_form.dart';
import './widgets/vibe_creation_form.dart';
import '../../services/oracle_api_service.dart';

/// Create Vibe & Event screen for content and event creation
class CreateVibeEvent extends StatefulWidget {
  const CreateVibeEvent({super.key});

  @override
  State<CreateVibeEvent> createState() => _CreateVibeEventState();
}

class _CreateVibeEventState extends State<CreateVibeEvent>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isPublishing = false;
  bool _isDraftSaving = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _startAutoSave();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _startAutoSave() {
    Future.delayed(const Duration(seconds: 30), () {
      if (mounted) {
        _saveDraft();
        _startAutoSave();
      }
    });
  }

  void _saveDraft() {
    setState(() {
      _isDraftSaving = true;
    });

    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _isDraftSaving = false;
        });
      }
    });
  }

  void _handleVibeCreated(
    String text,
    List<XFile> media,
    String? audioPath,
    List<String> tags,
  ) {
    setState(() {
      _isPublishing = true;
    });

    OracleApiService.createPost(
          content: text,
          mediaUrls: media.map((m) => m.path).toList(),
          audioUrl: audioPath,
          tags: tags,
        )
        .then((result) {
          if (mounted) {
            setState(() {
              _isPublishing = false;
            });

            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Vibe posted successfully!'),
                backgroundColor: Colors.green,
              ),
            );

            Navigator.pop(context);
          }
        })
        .catchError((e) {
          if (mounted) {
            setState(() {
              _isPublishing = false;
            });

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Failed to post: ${e.toString()}'),
                backgroundColor: Colors.red,
              ),
            );
          }
        });
  }

  void _handleEventCreated(Map<String, dynamic> eventData) {
    setState(() {
      _isPublishing = true;
    });

    OracleApiService.createEvent(
          title: eventData['title'],
          description: eventData['description'],
          startDate: eventData['startDate'],
          endDate: eventData['endDate'],
          location: eventData['location'],
          category: eventData['category'],
          price: eventData['price'],
          capacity: eventData['capacity'],
          imageUrl: eventData['imageUrl'],
        )
        .then((result) {
          if (mounted) {
            setState(() {
              _isPublishing = false;
            });

            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Event created successfully!'),
                backgroundColor: Colors.green,
              ),
            );

            Navigator.pop(context);
          }
        })
        .catchError((e) {
          if (mounted) {
            setState(() {
              _isPublishing = false;
            });

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Failed to create event: ${e.toString()}'),
                backgroundColor: Colors.red,
              ),
            );
          }
        });
  }

  void _showPreview() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildPreviewModal(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: CustomAppBar(
        variant: CustomAppBarVariant.detail,
        showBackButton: true,
        title: 'Create',
        actions: [
          if (_isDraftSaving)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 2.w),
              child: Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: theme.colorScheme.secondary,
                  ),
                ),
              ),
            ),
          TextButton(
            onPressed: _showPreview,
            child: Text(
              'Preview',
              style: theme.textTheme.bodyLarge?.copyWith(
                color: theme.colorScheme.secondary,
              ),
            ),
          ),
          TextButton(
            onPressed: _isPublishing
                ? null
                : () {
                    _tabController.index == 0
                        ? _handleVibeCreated('', [], null, [])
                        : _handleEventCreated({});
                  },
            child: _isPublishing
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: theme.colorScheme.secondary,
                    ),
                  )
                : Text(
                    _tabController.index == 0 ? 'Post' : 'Publish',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: theme.colorScheme.secondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildSegmentControl(theme),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                VibeCreationForm(onVibeCreated: _handleVibeCreated),
                EventCreationForm(onEventCreated: _handleEventCreated),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSegmentControl(ThemeData theme) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.colorScheme.outline),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: theme.colorScheme.secondary,
          borderRadius: BorderRadius.circular(10),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: theme.colorScheme.onSecondary,
        unselectedLabelColor: theme.colorScheme.onSurface,
        labelStyle: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: theme.textTheme.titleSmall,
        tabs: const [
          Tab(text: 'Create Vibe'),
          Tab(text: 'Create Event'),
        ],
      ),
    );
  }

  Widget _buildPreviewModal() {
    final theme = Theme.of(context);

    return Container(
      height: 90.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Close',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: theme.colorScheme.error,
                    ),
                  ),
                ),
                Text('Preview', style: theme.textTheme.titleMedium),
                const SizedBox(width: 60),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'visibility',
                    color: theme.colorScheme.secondary,
                    size: 64,
                  ),
                  SizedBox(height: 2.h),
                  Text('Preview Mode', style: theme.textTheme.headlineSmall),
                  SizedBox(height: 1.h),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8.w),
                    child: Text(
                      'This is how your ${_tabController.index == 0 ? 'vibe' : 'event'} will appear in the feed',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

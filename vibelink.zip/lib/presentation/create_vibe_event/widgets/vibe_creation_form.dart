import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import './media_attachment_section.dart';

/// Vibe creation form widget with text input, media attachments, and hashtag selector
class VibeCreationForm extends StatefulWidget {
  final Function(String, List<XFile>, String?, List<String>) onVibeCreated;

  const VibeCreationForm({super.key, required this.onVibeCreated});

  @override
  State<VibeCreationForm> createState() => _VibeCreationFormState();
}

class _VibeCreationFormState extends State<VibeCreationForm> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _hashtagController = TextEditingController();
  final List<XFile> _selectedMedia = [];
  String? _audioPath;
  final List<String> _selectedTags = [];
  final int _maxCharacters = 500;

  final List<String> _suggestedTags = [
    'Music',
    'Food',
    'Travel',
    'Fitness',
    'Art',
    'Technology',
    'Fashion',
    'Sports',
    'Gaming',
    'Photography',
    'Dance',
    'Comedy',
    'Business',
    'Wellness',
    'Education',
  ];

  @override
  void dispose() {
    _textController.dispose();
    _hashtagController.dispose();
    super.dispose();
  }

  void _handleMediaSelected(List<XFile> media) {
    setState(() {
      _selectedMedia.addAll(media);
    });
  }

  void _handleAudioRecorded(String path) {
    setState(() {
      _audioPath = path;
    });
  }

  void _removeMedia(int index) {
    setState(() {
      _selectedMedia.removeAt(index);
    });
  }

  void _removeAudio() {
    setState(() {
      _audioPath = null;
    });
  }

  void _addTag(String tag) {
    if (!_selectedTags.contains(tag) && _selectedTags.length < 5) {
      setState(() {
        _selectedTags.add(tag);
      });
    }
  }

  void _removeTag(String tag) {
    setState(() {
      _selectedTags.remove(tag);
    });
  }

  void _submitVibe() {
    if (_textController.text.trim().isEmpty &&
        _selectedMedia.isEmpty &&
        _audioPath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add some content to your vibe')),
      );
      return;
    }

    widget.onVibeCreated(
      _textController.text.trim(),
      _selectedMedia,
      _audioPath,
      _selectedTags,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final remainingChars = _maxCharacters - _textController.text.length;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: TextField(
              controller: _textController,
              maxLines: 8,
              maxLength: _maxCharacters,
              style: theme.textTheme.bodyLarge,
              decoration: InputDecoration(
                hintText: 'What\'s on your mind?',
                hintStyle: theme.textTheme.bodyLarge?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                counterText: '',
              ),
              onChanged: (value) {
                setState(() {});
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Text(
              '$remainingChars characters remaining',
              style: theme.textTheme.labelSmall?.copyWith(
                color: remainingChars < 50
                    ? theme.colorScheme.error
                    : theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          SizedBox(height: 2.h),
          if (_selectedMedia.isNotEmpty) _buildMediaPreview(theme),
          if (_audioPath != null) _buildAudioPreview(theme),
          SizedBox(height: 2.h),
          MediaAttachmentSection(
            onMediaSelected: _handleMediaSelected,
            onAudioRecorded: _handleAudioRecorded,
          ),
          SizedBox(height: 2.h),
          _buildHashtagSection(theme),
          SizedBox(height: 2.h),
          _buildSelectedTags(theme),
          SizedBox(height: 2.h),
          _buildSuggestedTags(theme),
          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildMediaPreview(ThemeData theme) {
    return Container(
      height: 20.h,
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _selectedMedia.length,
        itemBuilder: (context, index) {
          return Container(
            width: 30.w,
            margin: EdgeInsets.only(right: 2.w),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CustomImageWidget(
                    imageUrl: _selectedMedia[index].path,
                    width: 30.w,
                    height: 20.h,
                    fit: BoxFit.cover,
                    semanticLabel: 'Selected media preview ${index + 1}',
                  ),
                ),
                Positioned(
                  top: 1.h,
                  right: 1.w,
                  child: InkWell(
                    onTap: () => _removeMedia(index),
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.error,
                        shape: BoxShape.circle,
                      ),
                      child: CustomIconWidget(
                        iconName: 'close',
                        color: theme.colorScheme.onError,
                        size: 16,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildAudioPreview(ThemeData theme) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.colorScheme.outline),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.colorScheme.secondary.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: CustomIconWidget(
              iconName: 'mic',
              color: theme.colorScheme.secondary,
              size: 24,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Audio Recording', style: theme.textTheme.titleSmall),
                Text(
                  'Tap to play',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: _removeAudio,
            icon: CustomIconWidget(
              iconName: 'delete',
              color: theme.colorScheme.error,
              size: 24,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHashtagSection(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Add Vibe Tags', style: theme.textTheme.titleSmall),
          SizedBox(height: 1.h),
          TextField(
            controller: _hashtagController,
            style: theme.textTheme.bodyMedium,
            decoration: InputDecoration(
              hintText: 'Search or create tags...',
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: 'tag',
                  color: theme.colorScheme.onSurfaceVariant,
                  size: 20,
                ),
              ),
              suffixIcon: _hashtagController.text.isNotEmpty
                  ? IconButton(
                      onPressed: () {
                        if (_hashtagController.text.trim().isNotEmpty) {
                          _addTag(_hashtagController.text.trim());
                          _hashtagController.clear();
                        }
                      },
                      icon: CustomIconWidget(
                        iconName: 'add',
                        color: theme.colorScheme.secondary,
                        size: 24,
                      ),
                    )
                  : null,
            ),
            onChanged: (value) {
              setState(() {});
            },
            onSubmitted: (value) {
              if (value.trim().isNotEmpty) {
                _addTag(value.trim());
                _hashtagController.clear();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSelectedTags(ThemeData theme) {
    if (_selectedTags.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Selected Tags (${_selectedTags.length}/5)',
            style: theme.textTheme.labelMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Wrap(
            spacing: 2.w,
            runSpacing: 1.h,
            children: _selectedTags.map((tag) {
              return Chip(
                label: Text(tag),
                deleteIcon: CustomIconWidget(
                  iconName: 'close',
                  color: theme.colorScheme.onSecondaryContainer,
                  size: 18,
                ),
                onDeleted: () => _removeTag(tag),
                backgroundColor: theme.colorScheme.secondaryContainer
                    .withValues(alpha: 0.3),
                labelStyle: theme.textTheme.labelMedium?.copyWith(
                  color: theme.colorScheme.onSecondaryContainer,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSuggestedTags(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Suggested Tags',
            style: theme.textTheme.labelMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Wrap(
            spacing: 2.w,
            runSpacing: 1.h,
            children: _suggestedTags.map((tag) {
              final isSelected = _selectedTags.contains(tag);
              return FilterChip(
                label: Text(tag),
                selected: isSelected,
                onSelected: (_selectedTags.length < 5 || isSelected)
                    ? (selected) {
                        selected ? _addTag(tag) : _removeTag(tag);
                      }
                    : null,
                backgroundColor: theme.colorScheme.surface,
                selectedColor: theme.colorScheme.secondary.withValues(
                  alpha: 0.2,
                ),
                labelStyle: theme.textTheme.labelMedium?.copyWith(
                  color: isSelected
                      ? theme.colorScheme.secondary
                      : theme.colorScheme.onSurface,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

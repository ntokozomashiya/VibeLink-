import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../services/oracle_api_service.dart';

/// Profile setup modal for post-registration configuration
class ProfileSetupModalWidget extends StatefulWidget {
  final Map<String, dynamic> userData;
  final VoidCallback onComplete;

  const ProfileSetupModalWidget({
    super.key,
    required this.userData,
    required this.onComplete,
  });

  @override
  State<ProfileSetupModalWidget> createState() =>
      _ProfileSetupModalWidgetState();
}

class _ProfileSetupModalWidgetState extends State<ProfileSetupModalWidget> {
  final _formKey = GlobalKey<FormState>();
  final _bioController = TextEditingController();
  final _brandNameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _locationController = TextEditingController();
  final _websiteController = TextEditingController();

  XFile? _profilePhoto;
  final List<XFile> _mediaGallery = [];
  bool _isOrganizer = false;
  bool _isLoading = false;
  String? _selectedCategory;
  String? _selectedBusinessType;

  final List<String> _categories = [
    'Music & Entertainment',
    'Sports & Fitness',
    'Food & Beverage',
    'Arts & Culture',
    'Business & Networking',
    'Technology',
    'Travel & Adventure',
    'Wellness & Lifestyle',
  ];

  @override
  void dispose() {
    _bioController.dispose();
    _brandNameController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _websiteController.dispose();
    super.dispose();
  }

  Future<void> _pickProfilePhoto() async {
    HapticFeedback.lightImpact();

    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 85,
    );

    if (image != null) {
      setState(() => _profilePhoto = image);
    }
  }

  Future<void> _pickMediaGallery() async {
    HapticFeedback.lightImpact();

    final ImagePicker picker = ImagePicker();
    final List<XFile> images = await picker.pickMultiImage(
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 85,
    );

    if (images.isNotEmpty) {
      setState(() {
        _mediaGallery.addAll(images);
        if (_mediaGallery.length > 10) {
          _mediaGallery.removeRange(10, _mediaGallery.length);
        }
      });
    }
  }

  void _removeMediaItem(int index) {
    HapticFeedback.lightImpact();
    setState(() => _mediaGallery.removeAt(index));
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);
    HapticFeedback.mediumImpact();

    try {
      if (_isOrganizer) {
        await OracleApiService.setupOrganizerProfile(
          brandName: _brandNameController.text.trim(),
          businessType: _selectedBusinessType ?? _selectedCategory ?? 'General',
          website: _websiteController.text.trim().isNotEmpty
              ? _websiteController.text.trim()
              : null,
          description: _descriptionController.text.trim().isNotEmpty
              ? _descriptionController.text.trim()
              : null,
        );
      }

      if (mounted) {
        setState(() => _isLoading = false);
        Navigator.pop(context);
        widget.onComplete();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Profile setup failed: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: 85.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: EdgeInsets.only(top: 1.h),
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Complete Your Profile',
                  style: theme.textTheme.titleLarge,
                ),
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'close',
                    color: theme.colorScheme.onSurface,
                    size: 24,
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),

          Divider(height: 1, color: theme.colorScheme.outline),

          // Content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(6.w),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Profile photo
                    Center(
                      child: GestureDetector(
                        onTap: _pickProfilePhoto,
                        child: Container(
                          width: 30.w,
                          height: 30.w,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: theme.colorScheme.surfaceContainerHighest,
                            border: Border.all(
                              color: theme.colorScheme.outline,
                              width: 2,
                            ),
                          ),
                          child: _profilePhoto != null
                              ? ClipOval(
                                  child: CustomImageWidget(
                                    imageUrl: _profilePhoto!.path,
                                    width: 30.w,
                                    height: 30.w,
                                    fit: BoxFit.cover,
                                    semanticLabel: 'Selected profile photo',
                                  ),
                                )
                              : Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CustomIconWidget(
                                      iconName: 'add_a_photo',
                                      color: theme.colorScheme.onSurfaceVariant,
                                      size: 32,
                                    ),
                                    SizedBox(height: 1.h),
                                    Text(
                                      'Add Photo',
                                      style: theme.textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                        ),
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Bio
                    TextFormField(
                      controller: _bioController,
                      maxLines: 3,
                      maxLength: 150,
                      textInputAction: TextInputAction.newline,
                      decoration: const InputDecoration(
                        labelText: 'Bio',
                        hintText: 'Tell us about yourself...',
                        alignLabelWithHint: true,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please add a bio';
                        }
                        return null;
                      },
                    ),

                    SizedBox(height: 3.h),

                    // Organizer toggle
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Become an Organizer',
                                  style: theme.textTheme.titleMedium,
                                ),
                                SizedBox(height: 0.5.h),
                                Text(
                                  'Create and manage events',
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Switch(
                            value: _isOrganizer,
                            onChanged: (value) {
                              HapticFeedback.selectionClick();
                              setState(() => _isOrganizer = value);
                            },
                          ),
                        ],
                      ),
                    ),

                    if (_isOrganizer) ...[
                      SizedBox(height: 3.h),

                      // Brand name
                      TextFormField(
                        controller: _brandNameController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'Brand Name',
                          hintText: 'Your business or brand name',
                        ),
                        validator: (value) {
                          if (_isOrganizer &&
                              (value == null || value.isEmpty)) {
                            return 'Please enter your brand name';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 2.h),

                      // Category
                      DropdownButtonFormField<String>(
                        initialValue: _selectedCategory,
                        decoration: const InputDecoration(
                          labelText: 'Category',
                          hintText: 'Select your category',
                        ),
                        items: _categories.map((category) {
                          return DropdownMenuItem(
                            value: category,
                            child: Text(category),
                          );
                        }).toList(),
                        onChanged: (value) {
                          HapticFeedback.selectionClick();
                          setState(() => _selectedCategory = value);
                        },
                        validator: (value) {
                          if (_isOrganizer && value == null) {
                            return 'Please select a category';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 2.h),

                      // Description
                      TextFormField(
                        controller: _descriptionController,
                        maxLines: 3,
                        maxLength: 300,
                        decoration: const InputDecoration(
                          labelText: 'Description',
                          hintText: 'Describe your business...',
                          alignLabelWithHint: true,
                        ),
                        validator: (value) {
                          if (_isOrganizer &&
                              (value == null || value.isEmpty)) {
                            return 'Please add a description';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 2.h),

                      // Location
                      TextFormField(
                        controller: _locationController,
                        decoration: InputDecoration(
                          labelText: 'Location',
                          hintText: 'Business location',
                          suffixIcon: IconButton(
                            icon: CustomIconWidget(
                              iconName: 'location_on',
                              color: theme.colorScheme.secondary,
                              size: 20,
                            ),
                            onPressed: () {
                              // Handle location picker
                            },
                          ),
                        ),
                        validator: (value) {
                          if (_isOrganizer &&
                              (value == null || value.isEmpty)) {
                            return 'Please add your location';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Media gallery
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Media Gallery',
                            style: theme.textTheme.titleMedium,
                          ),
                          TextButton.icon(
                            onPressed: _pickMediaGallery,
                            icon: CustomIconWidget(
                              iconName: 'add_photo_alternate',
                              color: theme.colorScheme.secondary,
                              size: 20,
                            ),
                            label: Text('Add Photos'),
                          ),
                        ],
                      ),

                      SizedBox(height: 1.h),

                      _mediaGallery.isEmpty
                          ? Container(
                              height: 20.h,
                              decoration: BoxDecoration(
                                color:
                                    theme.colorScheme.surfaceContainerHighest,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: theme.colorScheme.outline,
                                  style: BorderStyle.solid,
                                ),
                              ),
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CustomIconWidget(
                                      iconName: 'photo_library',
                                      color: theme.colorScheme.onSurfaceVariant,
                                      size: 32,
                                    ),
                                    SizedBox(height: 1.h),
                                    Text(
                                      'No photos added',
                                      style: theme.textTheme.bodyMedium
                                          ?.copyWith(
                                            color: theme
                                                .colorScheme
                                                .onSurfaceVariant,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : SizedBox(
                              height: 20.h,
                              child: GridView.builder(
                                scrollDirection: Axis.horizontal,
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      mainAxisSpacing: 2.w,
                                      crossAxisSpacing: 1.h,
                                    ),
                                itemCount: _mediaGallery.length,
                                itemBuilder: (context, index) {
                                  return Stack(
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: CustomImageWidget(
                                          imageUrl: _mediaGallery[index].path,
                                          width: double.infinity,
                                          height: double.infinity,
                                          fit: BoxFit.cover,
                                          semanticLabel:
                                              'Gallery photo ${index + 1}',
                                        ),
                                      ),
                                      Positioned(
                                        top: 1.w,
                                        right: 1.w,
                                        child: GestureDetector(
                                          onTap: () => _removeMediaItem(index),
                                          child: Container(
                                            padding: EdgeInsets.all(1.w),
                                            decoration: BoxDecoration(
                                              color: Colors.black.withValues(
                                                alpha: 0.6,
                                              ),
                                              shape: BoxShape.circle,
                                            ),
                                            child: CustomIconWidget(
                                              iconName: 'close',
                                              color: Colors.white,
                                              size: 16,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ),
                    ],

                    SizedBox(height: 4.h),
                  ],
                ),
              ),
            ),
          ),

          // Bottom action
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              border: Border(
                top: BorderSide(color: theme.colorScheme.outline, width: 1),
              ),
            ),
            child: SafeArea(
              top: false,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _handleSubmit,
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 6.h),
                ),
                child: _isLoading
                    ? SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            theme.colorScheme.onSecondary,
                          ),
                        ),
                      )
                    : Text('Complete Setup'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

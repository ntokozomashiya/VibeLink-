import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../services/oracle_api_service.dart';

/// A sticky header widget for the home feed
///
/// Contains VibeLink logo, search functionality, and notification bell
class FeedHeaderWidget extends StatefulWidget {
  const FeedHeaderWidget({super.key, required this.onSearchTap});

  final VoidCallback onSearchTap;

  @override
  State<FeedHeaderWidget> createState() => _FeedHeaderWidgetState();
}

class _FeedHeaderWidgetState extends State<FeedHeaderWidget> {
  int _unreadCount = 0;

  @override
  void initState() {
    super.initState();
    _loadUnreadCount();
  }

  Future<void> _loadUnreadCount() async {
    if (OracleApiService.isAuthenticated) {
      try {
        final count = await OracleApiService.getUnreadNotificationCount();
        if (mounted) {
          setState(() => _unreadCount = count);
        }
      } catch (e) {
        print('Failed to load unread count: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        border: Border(
          bottom: BorderSide(
            color: theme.colorScheme.outline.withValues(alpha: 0.2),
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            // App Logo
            ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: CustomImageWidget(
                imageUrl: 'assets/images/1000238035-1767648250313.jpg',
                width: 40,
                height: 40,
                fit: BoxFit.cover,
                semanticLabel: 'VibeLink app logo',
              ),
            ),
            SizedBox(width: 3.w),
            // App Name
            Text(
              'VibeLink',
              style: GoogleFonts.inter(
                fontSize: 20.sp,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.primary,
              ),
            ),
            const Spacer(),
            // Notification Icon with Badge
            Stack(
              clipBehavior: Clip.none,
              children: [
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'notifications',
                    color: theme.colorScheme.onSurface,
                    size: 24,
                  ),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    Navigator.pushNamed(context, AppRoutes.notificationCenter);
                  },
                ),
                if (_unreadCount > 0)
                  Positioned(
                    right: 8,
                    top: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.error,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: theme.scaffoldBackgroundColor,
                          width: 1.5,
                        ),
                      ),
                      constraints: const BoxConstraints(
                        minWidth: 18,
                        minHeight: 18,
                      ),
                      child: Text(
                        _unreadCount > 99 ? '99+' : _unreadCount.toString(),
                        style: GoogleFonts.inter(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.onError,
                          height: 1.2,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
              ],
            ),
            // Search Icon
            IconButton(
              icon: CustomIconWidget(
                iconName: 'search',
                color: theme.colorScheme.onSurface,
                size: 24,
              ),
              onPressed: () {
                HapticFeedback.lightImpact();
                widget.onSearchTap();
              },
            ),
          ],
        ),
      ),
    );
  }
}

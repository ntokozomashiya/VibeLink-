import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/app_export.dart';

/// A widget that displays a single post card in the feed
///
/// Handles post content display, interactions (like, comment, share),
/// and multimedia content (images, videos, audio)
class FeedPostCardWidget extends StatefulWidget {
  const FeedPostCardWidget({
    super.key,
    required this.post,
    required this.onLike,
    required this.onComment,
    required this.onShare,
    required this.onUserTap,
    required this.onHashtagTap,
    required this.onLocationTap,
  });

  final Map<String, dynamic> post;
  final VoidCallback onLike;
  final VoidCallback onComment;
  final VoidCallback onShare;
  final VoidCallback onUserTap;
  final Function(String) onHashtagTap;
  final VoidCallback onLocationTap;

  @override
  State<FeedPostCardWidget> createState() => _FeedPostCardWidgetState();
}

class _FeedPostCardWidgetState extends State<FeedPostCardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _likeAnimationController;
  late Animation<double> _likeScaleAnimation;
  bool _showLikeAnimation = false;

  @override
  void initState() {
    super.initState();
    _likeAnimationController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _likeScaleAnimation = Tween<double>(begin: 0.0, end: 1.2).animate(
      CurvedAnimation(
        parent: _likeAnimationController,
        curve: Curves.elasticOut,
      ),
    );
  }

  @override
  void dispose() {
    _likeAnimationController.dispose();
    super.dispose();
  }

  void _handleDoubleTap() {
    HapticFeedback.mediumImpact();
    setState(() => _showLikeAnimation = true);
    _likeAnimationController.forward().then((_) {
      _likeAnimationController.reverse();
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted) {
          setState(() => _showLikeAnimation = false);
        }
      });
    });
    widget.onLike();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLiked = widget.post['isLiked'] as bool? ?? false;
    final mediaType = widget.post['mediaType'] as String? ?? 'none';

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildPostHeader(context, theme),
          if (mediaType != 'none')
            _buildMediaContent(context, theme, mediaType),
          _buildPostCaption(context, theme),
          _buildInteractionBar(context, theme, isLiked),
        ],
      ),
    );
  }

  Widget _buildPostHeader(BuildContext context, ThemeData theme) {
    return InkWell(
      onTap: widget.onUserTap,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            CustomImageWidget(
              imageUrl: widget.post['userAvatar'] as String,
              width: 40,
              height: 40,
              fit: BoxFit.cover,
              semanticLabel: widget.post['userAvatarLabel'] as String,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.post['userName'] as String,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    widget.post['timestamp'] as String,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: CustomIconWidget(
                iconName: 'more_vert',
                color: theme.colorScheme.onSurfaceVariant,
                size: 24,
              ),
              onPressed: () => _showPostOptions(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMediaContent(
    BuildContext context,
    ThemeData theme,
    String mediaType,
  ) {
    return GestureDetector(
      onDoubleTap: _handleDoubleTap,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: double.infinity,
            constraints: const BoxConstraints(maxHeight: 400),
            child: mediaType == 'image'
                ? CustomImageWidget(
                    imageUrl: widget.post['mediaUrl'] as String,
                    width: double.infinity,
                    height: 400,
                    fit: BoxFit.cover,
                    semanticLabel: widget.post['mediaLabel'] as String,
                  )
                : mediaType == 'video'
                ? _buildVideoPlayer(context, theme)
                : _buildAudioPlayer(context, theme),
          ),
          if (_showLikeAnimation)
            AnimatedBuilder(
              animation: _likeScaleAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _likeScaleAnimation.value,
                  child: CustomIconWidget(
                    iconName: 'favorite',
                    color: Colors.white,
                    size: 80,
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer(BuildContext context, ThemeData theme) {
    return Container(
      height: 400,
      color: Colors.black,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageWidget(
            imageUrl: widget.post['thumbnailUrl'] as String,
            width: double.infinity,
            height: 400,
            fit: BoxFit.cover,
            semanticLabel: 'Video thumbnail',
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3),
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(16),
            child: CustomIconWidget(
              iconName: 'play_arrow',
              color: Colors.white,
              size: 48,
            ),
          ),
          Positioned(
            bottom: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: 'volume_off',
                    color: Colors.white,
                    size: 16,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    widget.post['duration'] as String? ?? '0:00',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAudioPlayer(BuildContext context, ThemeData theme) {
    return Container(
      height: 120,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            theme.colorScheme.secondary.withValues(alpha: 0.2),
            theme.colorScheme.tertiary.withValues(alpha: 0.2),
          ],
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: theme.colorScheme.secondary,
              shape: BoxShape.circle,
            ),
            child: CustomIconWidget(
              iconName: 'play_arrow',
              color: theme.colorScheme.onSecondary,
              size: 32,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Audio Vibe',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  height: 40,
                  child: CustomPaint(
                    painter: WaveformPainter(
                      color: theme.colorScheme.secondary,
                    ),
                    size: const Size(double.infinity, 40),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Text(
            widget.post['duration'] as String? ?? '0:00',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPostCaption(BuildContext context, ThemeData theme) {
    final caption = widget.post['caption'] as String? ?? '';
    final location = widget.post['location'] as String?;
    final vibeCategory = widget.post['vibeCategory'] as String?;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (caption.isNotEmpty)
            RichText(
              text: TextSpan(
                style: theme.textTheme.bodyMedium,
                children: _buildCaptionSpans(caption, theme),
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          if (location != null || vibeCategory != null) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (location != null)
                  InkWell(
                    onTap: widget.onLocationTap,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: theme.colorScheme.outline.withValues(
                            alpha: 0.3,
                          ),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomIconWidget(
                            iconName: 'location_on',
                            color: theme.colorScheme.secondary,
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            location,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurface,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (vibeCategory != null)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.tertiary.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      vibeCategory,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.tertiary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  List<TextSpan> _buildCaptionSpans(String caption, ThemeData theme) {
    final spans = <TextSpan>[];
    final words = caption.split(' ');

    for (var word in words) {
      if (word.startsWith('#')) {
        spans.add(
          TextSpan(
            text: '$word ',
            style: TextStyle(
              color: theme.colorScheme.secondary,
              fontWeight: FontWeight.w600,
            ),
            recognizer: TapGestureRecognizer()
              ..onTap = () => widget.onHashtagTap(word),
          ),
        );
      } else {
        spans.add(TextSpan(text: '$word '));
      }
    }

    return spans;
  }

  Widget _buildInteractionBar(
    BuildContext context,
    ThemeData theme,
    bool isLiked,
  ) {
    final likeCount = widget.post['likeCount'] as int? ?? 0;
    final commentCount = widget.post['commentCount'] as int? ?? 0;
    final shareCount = widget.post['shareCount'] as int? ?? 0;

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          _buildInteractionButton(
            context,
            theme,
            icon: isLiked ? 'favorite' : 'favorite_border',
            count: likeCount,
            color: isLiked ? Colors.red : theme.colorScheme.onSurfaceVariant,
            onTap: widget.onLike,
          ),
          const SizedBox(width: 24),
          _buildInteractionButton(
            context,
            theme,
            icon: 'chat_bubble_outline',
            count: commentCount,
            color: theme.colorScheme.onSurfaceVariant,
            onTap: widget.onComment,
          ),
          const SizedBox(width: 24),
          _buildInteractionButton(
            context,
            theme,
            icon: 'repeat',
            count: shareCount,
            color: theme.colorScheme.onSurfaceVariant,
            onTap: widget.onShare,
          ),
          const Spacer(),
          IconButton(
            icon: CustomIconWidget(
              iconName: 'bookmark_border',
              color: theme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('Post saved'),
                  duration: const Duration(seconds: 2),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildInteractionButton(
    BuildContext context,
    ThemeData theme, {
    required String icon,
    required int count,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(iconName: icon, color: color, size: 24),
            if (count > 0) ...[
              const SizedBox(width: 4),
              Text(
                _formatCount(count),
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: color,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _formatCount(int count) {
    if (count >= 1000000) {
      return '${(count / 1000000).toStringAsFixed(1)}M';
    } else if (count >= 1000) {
      return '${(count / 1000).toStringAsFixed(1)}K';
    }
    return count.toString();
  }

  void _showPostOptions(BuildContext context) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      builder: (context) {
        final theme = Theme.of(context);
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'bookmark_border',
                  color: theme.colorScheme.onSurface,
                  size: 24,
                ),
                title: const Text('Save'),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(const SnackBar(content: Text('Post saved')));
                },
              ),
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'share',
                  color: theme.colorScheme.onSurface,
                  size: 24,
                ),
                title: const Text('Share External'),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Share functionality')),
                  );
                },
              ),
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'report',
                  color: theme.colorScheme.error,
                  size: 24,
                ),
                title: Text(
                  'Report',
                  style: TextStyle(color: theme.colorScheme.error),
                ),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Post reported')),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class WaveformPainter extends CustomPainter {
  final Color color;

  WaveformPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    final barWidth = size.width / 40;
    final heights = List.generate(40, (i) => (i % 3 + 1) * 10.0);

    for (var i = 0; i < 40; i++) {
      final x = i * barWidth;
      final height = heights[i];
      canvas.drawLine(
        Offset(x, size.height / 2 - height / 2),
        Offset(x, size.height / 2 + height / 2),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

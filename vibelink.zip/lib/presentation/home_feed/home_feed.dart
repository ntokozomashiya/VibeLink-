import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../services/oracle_api_service.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/feed_header_widget.dart';
import './widgets/feed_post_card_widget.dart';
import './widgets/vibe_stories_widget.dart';

/// Home Feed Screen - Main social feed with infinite scroll
///
/// Displays Instagram/TikTok-style posts with multimedia content,
/// social interactions, and real-time updates
class HomeFeed extends StatefulWidget {
  const HomeFeed({super.key});

  @override
  State<HomeFeed> createState() => _HomeFeedState();
}

class _HomeFeedState extends State<HomeFeed> {
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _posts = [];
  bool _isLoading = false;
  bool _hasMore = true;
  int _currentPage = 1;
  bool _useAIRecommendations = true;

  @override
  void initState() {
    super.initState();
    _loadInitialPosts();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      if (!_isLoading && _hasMore) {
        _loadMorePosts();
      }
    }
  }

  Future<void> _loadInitialPosts() async {
    setState(() => _isLoading = true);

    try {
      if (_useAIRecommendations) {
        final result = await OracleApiService.getRecommendations(
          page: 1,
          limit: 10,
        );
        final recommendations =
            result['recommendations'] as List<dynamic>? ?? [];
        setState(() {
          _posts.clear();
          _posts.addAll(
            recommendations.map((e) => e as Map<String, dynamic>).toList(),
          );
          _currentPage = 1;
          _isLoading = false;
        });
      } else {
        final posts = await OracleApiService.fetchPosts(page: 1, limit: 10);
        setState(() {
          _posts.clear();
          _posts.addAll(posts);
          _currentPage = 1;
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load posts: ${e.toString()}')),
        );
      }
    }
  }

  Future<void> _loadMorePosts() async {
    setState(() => _isLoading = true);

    try {
      final posts = await OracleApiService.fetchPosts(
        page: _currentPage + 1,
        limit: 10,
      );

      setState(() {
        if (posts.isEmpty) {
          _hasMore = false;
        } else {
          _posts.addAll(posts);
          _currentPage++;
        }
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _refreshFeed() async {
    HapticFeedback.mediumImpact();

    try {
      if (_useAIRecommendations) {
        final result = await OracleApiService.getRecommendations(
          page: 1,
          limit: 10,
        );
        final recommendations =
            result['recommendations'] as List<dynamic>? ?? [];
        setState(() {
          _posts.clear();
          _posts.addAll(
            recommendations.map((e) => e as Map<String, dynamic>).toList(),
          );
          _currentPage = 1;
          _hasMore = true;
        });
      } else {
        final posts = await OracleApiService.fetchPosts(page: 1, limit: 10);
        setState(() {
          _posts.clear();
          _posts.addAll(posts);
          _currentPage = 1;
          _hasMore = true;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to refresh: ${e.toString()}')),
        );
      }
    }
  }

  void _handlePostInteraction(int postId, String interactionType) {
    OracleApiService.trackInteraction(
      interactionType: interactionType,
      postId: postId,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _refreshFeed,
          color: theme.colorScheme.secondary,
          child: CustomScrollView(
            controller: _scrollController,
            slivers: [
              SliverToBoxAdapter(child: FeedHeaderWidget(onSearchTap: () {})),
              SliverToBoxAdapter(child: const VibeStoriesWidget()),
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _useAIRecommendations
                            ? 'Recommended for You'
                            : 'Latest Posts',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _useAIRecommendations = !_useAIRecommendations;
                          });
                          _loadInitialPosts();
                        },
                        icon: Icon(
                          _useAIRecommendations
                              ? Icons.auto_awesome
                              : Icons.feed,
                          size: 4.w,
                        ),
                        label: Text(
                          _useAIRecommendations ? 'AI' : 'All',
                          style: theme.textTheme.labelLarge,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (_isLoading && _posts.isEmpty)
                SliverFillRemaining(
                  child: Center(
                    child: CircularProgressIndicator(
                      color: theme.colorScheme.secondary,
                    ),
                  ),
                )
              else
                SliverList(
                  delegate: SliverChildBuilderDelegate((context, index) {
                    if (index >= _posts.length) {
                      return _isLoading
                          ? Padding(
                              padding: EdgeInsets.all(4.w),
                              child: Center(
                                child: CircularProgressIndicator(
                                  color: theme.colorScheme.secondary,
                                ),
                              ),
                            )
                          : const SizedBox.shrink();
                    }

                    return FeedPostCardWidget(
                      post: _posts[index],
                      onUserTap: () {},
                      onHashtagTap: (hashtag) {},
                      onLocationTap: () {},
                      onLike: () => _handlePostInteraction(
                        _posts[index]['post_id'],
                        'like',
                      ),
                      onComment: () => _handlePostInteraction(
                        _posts[index]['post_id'],
                        'comment',
                      ),
                      onShare: () => _handlePostInteraction(
                        _posts[index]['post_id'],
                        'share',
                      ),
                    );
                  }, childCount: _posts.length + (_isLoading ? 1 : 0)),
                ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: 0,
        onTap: (index) {
          if (index != 0) {
            Navigator.pushReplacementNamed(
              context,
              CustomBottomBarItem.values[index].route,
            );
          }
        },
      ),
    );
  }
}
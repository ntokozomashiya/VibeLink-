import 'package:flutter/material.dart';

class CustomRatingBar extends StatelessWidget {
  final double rating;
  final Function(double)? onRatingUpdate;
  final double itemSize;
  final Color color;
  final bool isIndicator;

  const CustomRatingBar({
    super.key,
    required this.rating,
    this.onRatingUpdate,
    this.itemSize = 24,
    required this.color,
    this.isIndicator = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        final starValue = index + 1;
        final isFilled = rating >= starValue;
        final isHalfFilled = rating >= starValue - 0.5 && rating < starValue;

        return GestureDetector(
          onTap: isIndicator
              ? null
              : () {
                  if (onRatingUpdate != null) {
                    onRatingUpdate!(starValue.toDouble());
                  }
                },
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: itemSize * 0.05),
            child: Icon(
              isFilled
                  ? Icons.star
                  : isHalfFilled
                  ? Icons.star_half
                  : Icons.star_border,
              size: itemSize,
              color: color,
            ),
          ),
        );
      }),
    );
  }
}

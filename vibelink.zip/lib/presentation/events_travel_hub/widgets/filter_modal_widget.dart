import 'package:flutter/material.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

/// Filter modal widget for event filtering
class FilterModalWidget extends StatefulWidget {
  const FilterModalWidget({
    super.key,
    required this.activeFilters,
    required this.onApplyFilters,
  });

  final Map<String, String> activeFilters;
  final Function(Map<String, String>) onApplyFilters;

  @override
  State<FilterModalWidget> createState() => _FilterModalWidgetState();
}

class _FilterModalWidgetState extends State<FilterModalWidget> {
  late Map<String, String> _selectedFilters;
  bool _cityExpanded = true;
  bool _vibeTypeExpanded = true;
  bool _priceRangeExpanded = true;

  final List<String> _cities = [
    'Cape Town',
    'Johannesburg',
    'Durban',
    'Pretoria',
    'Port Elizabeth',
  ];

  final List<String> _vibeTypes = [
    'Music',
    'Business',
    'Food & Drink',
    'Wellness',
    'Arts & Culture',
    'Nightlife',
    'Sports',
  ];

  final List<String> _priceRanges = [
    'Under R 300',
    'R 300 - R 600',
    'Over R 600',
  ];

  @override
  void initState() {
    super.initState();
    _selectedFilters = Map.from(widget.activeFilters);
  }

  void _clearFilters() {
    setState(() => _selectedFilters.clear());
  }

  void _applyFilters() {
    widget.onApplyFilters(_selectedFilters);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(20),
              ),
            ),
            child: Column(
              children: [
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.onSurfaceVariant.withValues(
                      alpha: 0.3,
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Filters',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    TextButton(
                      onPressed: _clearFilters,
                      child: Text(
                        'Clear All',
                        style: theme.textTheme.labelLarge?.copyWith(
                          color: theme.colorScheme.secondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Filter options
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _buildFilterSection(
                  theme,
                  'City',
                  _cityExpanded,
                  () => setState(() => _cityExpanded = !_cityExpanded),
                  _cities
                      .map(
                        (city) => _buildFilterOption(
                          theme,
                          city,
                          _selectedFilters['city'] == city,
                          () => setState(() {
                            _selectedFilters['city'] == city
                                ? _selectedFilters.remove('city')
                                : _selectedFilters['city'] = city;
                          }),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 20),
                _buildFilterSection(
                  theme,
                  'Vibe Type',
                  _vibeTypeExpanded,
                  () => setState(() => _vibeTypeExpanded = !_vibeTypeExpanded),
                  _vibeTypes
                      .map(
                        (type) => _buildFilterOption(
                          theme,
                          type,
                          _selectedFilters['vibeType'] == type,
                          () => setState(() {
                            _selectedFilters['vibeType'] == type
                                ? _selectedFilters.remove('vibeType')
                                : _selectedFilters['vibeType'] = type;
                          }),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 20),
                _buildFilterSection(
                  theme,
                  'Price Range',
                  _priceRangeExpanded,
                  () => setState(
                    () => _priceRangeExpanded = !_priceRangeExpanded,
                  ),
                  _priceRanges
                      .map(
                        (range) => _buildFilterOption(
                          theme,
                          range,
                          _selectedFilters['priceRange'] == range,
                          () => setState(() {
                            _selectedFilters['priceRange'] == range
                                ? _selectedFilters.remove('priceRange')
                                : _selectedFilters['priceRange'] = range;
                          }),
                        ),
                      )
                      .toList(),
                ),
              ],
            ),
          ),
          // Apply button
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              boxShadow: [
                BoxShadow(
                  color: theme.colorScheme.shadow.withValues(alpha: 0.08),
                  blurRadius: 8,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _applyFilters,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: Text(
                    'Apply Filters (${_selectedFilters.length})',
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection(
    ThemeData theme,
    String title,
    bool isExpanded,
    VoidCallback onToggle,
    List<Widget> options,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: onToggle,
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  CustomIconWidget(
                    iconName: isExpanded ? 'expand_less' : 'expand_more',
                    color: theme.colorScheme.onSurface,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Column(children: options),
            ),
        ],
      ),
    );
  }

  Widget _buildFilterOption(
    ThemeData theme,
    String label,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: theme.textTheme.bodyLarge?.copyWith(
                color: isSelected
                    ? theme.colorScheme.secondary
                    : theme.colorScheme.onSurface,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
            if (isSelected)
              CustomIconWidget(
                iconName: 'check_circle',
                color: theme.colorScheme.secondary,
                size: 24,
              ),
          ],
        ),
      ),
    );
  }
}

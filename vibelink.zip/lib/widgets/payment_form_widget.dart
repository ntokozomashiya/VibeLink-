import 'package:flutter/material.dart';
import '../services/stripe_payment_service.dart';
import '../services/enhanced_api_service.dart';
import '../widgets/error_dialog_helper.dart';

/// Payment Form Widget
/// Handles Stripe payment card input and processing
class PaymentFormWidget extends StatefulWidget {
  final double amount;
  final String description;
  final Map<String, dynamic>? metadata;
  final Function(String paymentIntentId) onPaymentSuccess;

  const PaymentFormWidget({
    super.key,
    required this.amount,
    required this.description,
    this.metadata,
    required this.onPaymentSuccess,
  });

  @override
  State<PaymentFormWidget> createState() => _PaymentFormWidgetState();
}

class _PaymentFormWidgetState extends State<PaymentFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final _cardNumberController = TextEditingController();
  final _expMonthController = TextEditingController();
  final _expYearController = TextEditingController();
  final _cvcController = TextEditingController();
  bool _isProcessing = false;

  @override
  void dispose() {
    _cardNumberController.dispose();
    _expMonthController.dispose();
    _expYearController.dispose();
    _cvcController.dispose();
    super.dispose();
  }

  Future<void> _processPayment() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isProcessing = true);

    try {
      final paymentMethod = await StripePaymentService.createPaymentMethod(
        cardNumber: _cardNumberController.text.replaceAll(' ', ''),
        expMonth: _expMonthController.text,
        expYear: _expYearController.text,
        cvc: _cvcController.text,
      );

      final paymentIntent = await StripePaymentService.createPaymentIntent(
        amount: widget.amount,
        currency: 'usd',
        description: widget.description,
        metadata: widget.metadata,
      );

      final confirmedPayment = await StripePaymentService.confirmPayment(
        paymentIntentId: paymentIntent['id'],
        paymentMethodId: paymentMethod['id'],
      );

      if (confirmedPayment['status'] == 'succeeded') {
        if (mounted) {
          Navigator.of(context).pop();
          widget.onPaymentSuccess(confirmedPayment['id']);
          ErrorDialogHelper.showSuccessDialog(
            context,
            'Payment Successful',
            'Your payment has been processed successfully.',
          );
        }
      } else {
        throw Exception('Payment not completed');
      }
    } on ApiException catch (e) {
      if (mounted) {
        ErrorDialogHelper.showApiErrorDialog(
          context,
          e,
          onRetry: _processPayment,
        );
      }
    } catch (e) {
      if (mounted) {
        ErrorDialogHelper.showPaymentErrorDialog(
          context,
          e.toString(),
          onRetry: _processPayment,
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isProcessing = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Payment Details',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: theme.colorScheme.secondary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Total Amount', style: theme.textTheme.titleMedium),
                  Text(
                    '\$${widget.amount.toStringAsFixed(2)}',
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: theme.colorScheme.secondary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: _cardNumberController,
              decoration: const InputDecoration(
                labelText: 'Card Number',
                hintText: '1234 5678 9012 3456',
                prefixIcon: Icon(Icons.credit_card),
              ),
              keyboardType: TextInputType.number,
              maxLength: 19,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter card number';
                }
                final cleaned = value.replaceAll(' ', '');
                if (cleaned.length < 13 || cleaned.length > 19) {
                  return 'Invalid card number';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _expMonthController,
                    decoration: const InputDecoration(
                      labelText: 'Exp Month',
                      hintText: 'MM',
                    ),
                    keyboardType: TextInputType.number,
                    maxLength: 2,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Required';
                      }
                      final month = int.tryParse(value);
                      if (month == null || month < 1 || month > 12) {
                        return 'Invalid';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextFormField(
                    controller: _expYearController,
                    decoration: const InputDecoration(
                      labelText: 'Exp Year',
                      hintText: 'YY',
                    ),
                    keyboardType: TextInputType.number,
                    maxLength: 2,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextFormField(
                    controller: _cvcController,
                    decoration: const InputDecoration(
                      labelText: 'CVC',
                      hintText: '123',
                    ),
                    keyboardType: TextInputType.number,
                    maxLength: 4,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Required';
                      }
                      if (value.length < 3) {
                        return 'Invalid';
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isProcessing ? null : _processPayment,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _isProcessing
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Colors.white,
                          ),
                        ),
                      )
                    : Text(
                        'Pay \$${widget.amount.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.lock, size: 16, color: Colors.grey),
                const SizedBox(width: 8),
                Text(
                  'Secured by Stripe',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

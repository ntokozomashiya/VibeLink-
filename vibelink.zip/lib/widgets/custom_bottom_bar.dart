import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Navigation item configuration for the bottom navigation bar
enum CustomBottomBarItem {
  home(
    route: '/home-feed',
    icon: Icons.home_outlined,
    activeIcon: Icons.home,
    label: 'Home',
  ),
  events(
    route: '/events-travel-hub',
    icon: Icons.calendar_today_outlined,
    activeIcon: Icons.calendar_today,
    label: 'Events',
  ),
  create(
    route: '/create-vibe-event',
    icon: Icons.add_circle_outline,
    activeIcon: Icons.add_circle,
    label: 'Create',
  ),
  messages(
    route: '/messaging-community',
    icon: Icons.chat_bubble_outline,
    activeIcon: Icons.chat_bubble,
    label: 'Messages',
  ),
  profile(
    route: '/profile-search-settings',
    icon: Icons.person_outline,
    activeIcon: Icons.person,
    label: 'Profile',
  );

  const CustomBottomBarItem({
    required this.route,
    required this.icon,
    required this.activeIcon,
    required this.label,
  });

  final String route;
  final IconData icon;
  final IconData activeIcon;
  final String label;
}

/// A custom bottom navigation bar widget for VibeLink app
///
/// Implements thumb-optimized navigation with smooth transitions and haptic feedback.
/// Supports badge notifications and platform-aware styling.
///
/// Example usage:
/// ```dart
/// Scaffold(
///   body: _pages[_currentIndex],
///   bottomNavigationBar: CustomBottomBar(
///     currentIndex: _currentIndex,
///     onTap: (index) {
///       setState(() {
///         _currentIndex = index;
///       });
///     },
///     badges: {1: '3', 3: '12'},
///   ),
/// )
/// ```
class CustomBottomBar extends StatefulWidget {
  /// Creates a custom bottom navigation bar
  const CustomBottomBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
    this.badges = const {},
    this.enableHapticFeedback = true,
    this.animationDuration = const Duration(milliseconds: 200),
    this.elevation = 8.0,
    this.showLabels = true,
  });

  /// The index of the currently selected item
  final int currentIndex;

  /// Callback when a navigation item is tapped
  final ValueChanged<int> onTap;

  /// Badge notifications for specific items (index: badge text)
  /// Example: {1: '3', 3: '12'} shows badges on Events and Messages
  final Map<int, String> badges;

  /// Whether to provide haptic feedback on tap
  final bool enableHapticFeedback;

  /// Duration of the selection animation
  final Duration animationDuration;

  /// Elevation of the bottom bar
  final double elevation;

  /// Whether to show labels below icons
  final bool showLabels;

  @override
  State<CustomBottomBar> createState() => _CustomBottomBarState();
}

class _CustomBottomBarState extends State<CustomBottomBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  int _previousIndex = 0;

  @override
  void initState() {
    super.initState();
    _previousIndex = widget.currentIndex;
    _animationController = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.85).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(CustomBottomBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.currentIndex != widget.currentIndex) {
      _previousIndex = oldWidget.currentIndex;
      _animationController.forward().then((_) {
        _animationController.reverse();
      });
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _handleTap(int index) {
    if (widget.enableHapticFeedback) {
      HapticFeedback.lightImpact();
    }
    widget.onTap(index);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final bottomNavTheme = theme.bottomNavigationBarTheme;

    return Container(
      decoration: BoxDecoration(
        color: bottomNavTheme.backgroundColor ?? colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: widget.elevation,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Container(
          height: widget.showLabels ? 72 : 60,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(
              CustomBottomBarItem.values.length,
              (index) => _buildNavigationItem(
                context,
                CustomBottomBarItem.values[index],
                index,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavigationItem(
    BuildContext context,
    CustomBottomBarItem item,
    int index,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final bottomNavTheme = theme.bottomNavigationBarTheme;
    final isSelected = widget.currentIndex == index;
    final badge = widget.badges[index];

    final selectedColor =
        bottomNavTheme.selectedItemColor ?? colorScheme.primary;
    final unselectedColor =
        bottomNavTheme.unselectedItemColor ?? colorScheme.onSurfaceVariant;

    return Expanded(
      child: GestureDetector(
        onTap: () => _handleTap(index),
        behavior: HitTestBehavior.opaque,
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            final scale = isSelected && _previousIndex == index
                ? _scaleAnimation.value
                : 1.0;

            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    // Icon with smooth transition
                    AnimatedSwitcher(
                      duration: widget.animationDuration,
                      transitionBuilder: (child, animation) {
                        return FadeTransition(
                          opacity: animation,
                          child: ScaleTransition(
                            scale: animation,
                            child: child,
                          ),
                        );
                      },
                      child: Icon(
                        isSelected ? item.activeIcon : item.icon,
                        key: ValueKey(isSelected),
                        size: isSelected ? 28 : 24,
                        color: isSelected ? selectedColor : unselectedColor,
                      ),
                    ),
                    // Badge indicator
                    if (badge != null && badge.isNotEmpty)
                      Positioned(
                        right: -8,
                        top: -4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: colorScheme.error,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: colorScheme.surface,
                              width: 1.5,
                            ),
                          ),
                          constraints: const BoxConstraints(
                            minWidth: 18,
                            minHeight: 18,
                          ),
                          child: Text(
                            badge.length > 2 ? '99+' : badge,
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: colorScheme.onError,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              height: 1.2,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                  ],
                ),
                // Label with fade animation
                if (widget.showLabels) ...[
                  const SizedBox(height: 4),
                  AnimatedDefaultTextStyle(
                    duration: widget.animationDuration,
                    style:
                        (isSelected
                            ? bottomNavTheme.selectedLabelStyle
                            : bottomNavTheme.unselectedLabelStyle) ??
                        theme.textTheme.labelMedium!.copyWith(
                          color: isSelected ? selectedColor : unselectedColor,
                          fontWeight: isSelected
                              ? FontWeight.w600
                              : FontWeight.w400,
                        ),
                    child: Text(
                      item.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Extension to easily navigate using CustomBottomBarItem
extension CustomBottomBarNavigation on BuildContext {
  /// Navigate to a specific bottom bar item route
  void navigateToBottomBarItem(CustomBottomBarItem item) {
    Navigator.pushNamed(this, item.route);
  }
}

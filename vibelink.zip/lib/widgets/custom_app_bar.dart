import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// App bar variant types for different screen contexts
enum CustomAppBarVariant {
  /// Standard app bar with title and optional actions
  standard,

  /// App bar with search functionality
  search,

  /// App bar with back button and title
  detail,

  /// Transparent app bar for overlay on content
  transparent,

  /// App bar with large title for main sections
  large,
}

/// A custom app bar widget for VibeLink app
///
/// Provides consistent navigation and branding across the application with
/// support for multiple variants, search functionality, and smooth animations.
///
/// Example usage:
/// ```dart
/// Scaffold(
///   appBar: CustomAppBar(
///     variant: CustomAppBarVariant.standard,
///     title: 'Home Feed',
///     actions: [
///       IconButton(
///         icon: Icon(Icons.notifications_outlined),
///         onPressed: () {},
///       ),
///     ],
///   ),
///   body: YourContent(),
/// )
/// ```
class CustomAppBar extends StatefulWidget implements PreferredSizeWidget {
  /// Creates a custom app bar
  const CustomAppBar({
    super.key,
    this.variant = CustomAppBarVariant.standard,
    this.title,
    this.leading,
    this.actions,
    this.onSearchChanged,
    this.searchHint = 'Search...',
    this.showBackButton = false,
    this.centerTitle = false,
    this.elevation,
    this.backgroundColor,
    this.foregroundColor,
    this.systemOverlayStyle,
    this.flexibleSpace,
    this.bottom,
  });

  /// The variant style of the app bar
  final CustomAppBarVariant variant;

  /// The title text or widget to display
  final String? title;

  /// Custom leading widget (overrides back button if provided)
  final Widget? leading;

  /// Action widgets to display on the right side
  final List<Widget>? actions;

  /// Callback when search text changes (only for search variant)
  final ValueChanged<String>? onSearchChanged;

  /// Hint text for search field
  final String searchHint;

  /// Whether to show back button (for detail variant)
  final bool showBackButton;

  /// Whether to center the title
  final bool centerTitle;

  /// Custom elevation (defaults to theme value)
  final double? elevation;

  /// Custom background color (defaults to theme value)
  final Color? backgroundColor;

  /// Custom foreground color (defaults to theme value)
  final Color? foregroundColor;

  /// System overlay style for status bar
  final SystemUiOverlayStyle? systemOverlayStyle;

  /// Flexible space widget for custom content
  final Widget? flexibleSpace;

  /// Bottom widget (typically TabBar)
  final PreferredSizeWidget? bottom;

  @override
  State<CustomAppBar> createState() => _CustomAppBarState();

  @override
  Size get preferredSize {
    double height = kToolbarHeight;
    if (variant == CustomAppBarVariant.large) {
      height = 120;
    }
    if (bottom != null) {
      height += bottom!.preferredSize.height;
    }
    return Size.fromHeight(height);
  }
}

class _CustomAppBarState extends State<CustomAppBar>
    with SingleTickerProviderStateMixin {
  late TextEditingController _searchController;
  late FocusNode _searchFocusNode;
  bool _isSearchActive = false;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _searchFocusNode = FocusNode();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    widget.onSearchChanged?.call(_searchController.text);
  }

  void _toggleSearch() {
    setState(() {
      _isSearchActive = !_isSearchActive;
      if (_isSearchActive) {
        _searchFocusNode.requestFocus();
      } else {
        _searchController.clear();
        _searchFocusNode.unfocus();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appBarTheme = theme.appBarTheme;
    final colorScheme = theme.colorScheme;

    final backgroundColor =
        widget.backgroundColor ??
        (widget.variant == CustomAppBarVariant.transparent
            ? Colors.transparent
            : appBarTheme.backgroundColor ?? colorScheme.surface);

    final foregroundColor =
        widget.foregroundColor ??
        appBarTheme.foregroundColor ??
        colorScheme.onSurface;

    final elevation =
        widget.elevation ??
        (widget.variant == CustomAppBarVariant.transparent
            ? 0
            : appBarTheme.elevation ?? 0);

    return AppBar(
      systemOverlayStyle:
          widget.systemOverlayStyle ??
          (theme.brightness == Brightness.light
              ? SystemUiOverlayStyle.dark
              : SystemUiOverlayStyle.light),
      backgroundColor: backgroundColor,
      foregroundColor: foregroundColor,
      elevation: elevation,
      centerTitle: widget.centerTitle,
      toolbarHeight: widget.variant == CustomAppBarVariant.large ? 120 : null,
      leading: _buildLeading(context, foregroundColor),
      title: _buildTitle(context),
      actions: _buildActions(context, foregroundColor),
      flexibleSpace: widget.flexibleSpace,
      bottom: widget.bottom,
    );
  }

  Widget? _buildLeading(BuildContext context, Color foregroundColor) {
    if (widget.leading != null) {
      return widget.leading;
    }

    if (widget.showBackButton || Navigator.of(context).canPop()) {
      return IconButton(
        icon: const Icon(Icons.arrow_back),
        color: foregroundColor,
        onPressed: () {
          HapticFeedback.lightImpact();
          Navigator.of(context).pop();
        },
        tooltip: 'Back',
      );
    }

    return null;
  }

  Widget? _buildTitle(BuildContext context) {
    final theme = Theme.of(context);

    switch (widget.variant) {
      case CustomAppBarVariant.search:
        if (_isSearchActive) {
          return TextField(
            controller: _searchController,
            focusNode: _searchFocusNode,
            style: theme.textTheme.bodyLarge,
            decoration: InputDecoration(
              hintText: widget.searchHint,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: EdgeInsets.zero,
            ),
            textInputAction: TextInputAction.search,
          );
        }
        return Text(
          widget.title ?? 'Search',
          style: widget.variant == CustomAppBarVariant.large
              ? theme.textTheme.headlineMedium
              : theme.appBarTheme.titleTextStyle,
        );

      case CustomAppBarVariant.large:
        return Align(
          alignment: Alignment.bottomLeft,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              widget.title ?? '',
              style: theme.textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        );

      case CustomAppBarVariant.standard:
      case CustomAppBarVariant.detail:
      case CustomAppBarVariant.transparent:
        if (widget.title != null) {
          return Text(widget.title!, style: theme.appBarTheme.titleTextStyle);
        }
        return null;
    }
  }

  List<Widget>? _buildActions(BuildContext context, Color foregroundColor) {
    final theme = Theme.of(context);
    final actions = <Widget>[];

    // Add search toggle for search variant
    if (widget.variant == CustomAppBarVariant.search) {
      actions.add(
        IconButton(
          icon: Icon(_isSearchActive ? Icons.close : Icons.search),
          color: foregroundColor,
          onPressed: () {
            HapticFeedback.lightImpact();
            _toggleSearch();
          },
          tooltip: _isSearchActive ? 'Close search' : 'Search',
        ),
      );
    }

    // Add custom actions
    if (widget.actions != null) {
      actions.addAll(widget.actions!);
    }

    return actions.isEmpty ? null : actions;
  }
}

/// A custom sliver app bar for scrollable content
///
/// Provides collapsing header functionality with smooth animations
///
/// Example usage:
/// ```dart
/// CustomScrollView(
///   slivers: [
///     CustomSliverAppBar(
///       title: 'Events',
///       expandedHeight: 200,
///       flexibleSpace: YourHeaderContent(),
///     ),
///     SliverList(...),
///   ],
/// )
/// ```
class CustomSliverAppBar extends StatelessWidget {
  const CustomSliverAppBar({
    super.key,
    this.title,
    this.leading,
    this.actions,
    this.flexibleSpace,
    this.expandedHeight = 200,
    this.floating = false,
    this.pinned = true,
    this.snap = false,
    this.backgroundColor,
    this.foregroundColor,
    this.elevation,
    this.systemOverlayStyle,
  });

  final String? title;
  final Widget? leading;
  final List<Widget>? actions;
  final Widget? flexibleSpace;
  final double expandedHeight;
  final bool floating;
  final bool pinned;
  final bool snap;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double? elevation;
  final SystemUiOverlayStyle? systemOverlayStyle;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appBarTheme = theme.appBarTheme;
    final colorScheme = theme.colorScheme;

    return SliverAppBar(
      systemOverlayStyle:
          systemOverlayStyle ??
          (theme.brightness == Brightness.light
              ? SystemUiOverlayStyle.dark
              : SystemUiOverlayStyle.light),
      backgroundColor:
          backgroundColor ?? appBarTheme.backgroundColor ?? colorScheme.surface,
      foregroundColor:
          foregroundColor ??
          appBarTheme.foregroundColor ??
          colorScheme.onSurface,
      elevation: elevation ?? appBarTheme.elevation ?? 0,
      expandedHeight: expandedHeight,
      floating: floating,
      pinned: pinned,
      snap: snap,
      leading: leading,
      title: title != null ? Text(title!) : null,
      actions: actions,
      flexibleSpace: flexibleSpace != null
          ? FlexibleSpaceBar(
              background: flexibleSpace,
              collapseMode: CollapseMode.parallax,
            )
          : null,
    );
  }
}

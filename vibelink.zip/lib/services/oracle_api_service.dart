import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';

/// Oracle VPS Backend API Service
/// Handles all REST API communication with Oracle-hosted backend
class OracleApiService {
  static const String _baseUrl = 'https://api.vibelink.ibetechnologies.co.za/api';

  static const String _apiKey = String.fromEnvironment(
    'ORACLE_API_KEY',
    defaultValue: '',
  );

  static String? _authToken;
  static Map<String, dynamic>? _currentUser;

  /// Get current authenticated user
  static Map<String, dynamic>? get currentUser => _currentUser;

  /// Check if user is authenticated
  static bool get isAuthenticated => _authToken != null;

  /// Generate request headers with authentication
  static Map<String, String> _getHeaders({bool includeAuth = true}) {
    final headers = {'Content-Type': 'application/json', 'X-API-Key': _apiKey};

    if (includeAuth && _authToken != null) {
      headers['Authorization'] = 'Bearer $_authToken';
    }

    return headers;
  }

  /// Handle API response and errors
  static dynamic _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.body.isEmpty) return null;
      return json.decode(response.body);
    } else {
      throw Exception('API Error ${response.statusCode}: ${response.body}');
    }
  }

  // ==================== AUTHENTICATION ====================

  /// Login with email and password
  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/auth/login'),
      headers: _getHeaders(includeAuth: false),
      body: json.encode({'email': email, 'password': password,
    );

    final data = _handleResponse(response);
    _authToken = data['token'];
    _currentUser = data['user'];

    return data;
  }

  /// Register new user
  static Future<Map<String, dynamic>> register({
    required String email,
    required String password,
    required String fullName,
    String? phone,
    String? bio,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/auth/register'),
      headers: _getHeaders(includeAuth: false),
      body: json.encode({
        'email': email,
        'password':Password,
        'full_name': fullName,
        'phone': phone,
        'bio': bio,
      }),
    );

    final data = _handleResponse(response);
    _authToken = data['token'];
    _currentUser = data['user'];

    return data;
  }

  /// Complete organizer profile setup
  static Future<Map<String, dynamic>> setupOrganizerProfile({
    required String brandName,
    required String businessType,
    String? website,
    String? description,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/auth/setup-organizer'),
      headers: _getHeaders(),
      body: json.encode({
        'brand_name': brandName,
        'business_type': businessType,
        'website': website,
        'description': description,
      }),
    );

    final data = _handleResponse(response);
    _currentUser = data['user'];

    return data;
  }

  /// Logout current user
  static Future<void> logout() async {
    try {
      await http.post(
        Uri.parse('$_baseUrl/auth/logout'),
        headers: _getHeaders(),
      );
    } finally {
      _authToken = null;
      _currentUser = null;
    }
  }

  // ==================== POSTS/VIBES ====================

  /// Fetch posts feed with pagination
  static Future<List<Map<String, dynamic>>> fetchPosts({
    int page = 1,
    int limit = 10,
  }) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/posts?page=$page&limit=$limit'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['posts']);
  }

  /// Create new post/vibe
  static Future<Map<String, dynamic>> createPost({
    required String content,
    List<String>? mediaUrls,
    String? audioUrl,
    List<String>? tags,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/posts'),
      headers: _getHeaders(),
      body: json.encode({
        'content': content,
        'media_urls': mediaUrls,
        'audio_url': audioUrl,
        'tags': tags,
      }),
    );

    return _handleResponse(response);
  }

  /// Like a post
  static Future<void> likePost(int postId) async {
    await http.post(
      Uri.parse('$_baseUrl/posts/$postId/like'),
      headers: _getHeaders(),
    );
  }

  /// Unlike a post
  static Future<void> unlikePost(int postId) async {
    await http.delete(
      Uri.parse('$_baseUrl/posts/$postId/like'),
      headers: _getHeaders(),
    );
  }

  /// Add comment to post
  static Future<Map<String, dynamic>> addComment(
    int postId,
    String comment,
  ) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/posts/$postId/comments'),
      headers: _getHeaders(),
      body: json.encode({'comment': comment}),
    );

    return _handleResponse(response);
  }

  // ==================== EVENTS ====================

  /// Fetch events with filters
  static Future<List<Map<String, dynamic>>> fetchEvents({
    String? category,
    String? location,
    DateTime? startDate,
    DateTime? endDate,
    int page = 1,
    int limit = 10,
  }) async {
    final queryParams = {
      'page': page.toString(),
      'limit': limit.toString(),
      if (category != null) 'category': category,
      if (location != null) 'location': location,
      if (startDate != null) 'start_date': startDate.toIso8601String(),
      if (endDate != null) 'end_date': endDate.toIso8601String(),
    };

    final uri = Uri.parse(
      '$_baseUrl/events',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    final data = _handleResponse(response);

    return List<Map<String, dynamic>>.from(data['events']);
  }

  /// Create new event
  static Future<Map<String, dynamic>> createEvent({
    required String title,
    required String description,
    required DateTime startDate,
    required DateTime endDate,
    required String location,
    required String category,
    required double price,
    required int capacity,
    String? imageUrl,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/events'),
      headers: _getHeaders(),
      body: json.encode({
        'title': title,
        'description': description,
        'start_date': startDate.toIso8601String(),
        'end_date': endDate.toIso8601String(),
        'location': location,
        'category': category,
        'price': price,
        'capacity': capacity,
        'image_url': imageUrl,
      }),
    );

    return _handleResponse(response);
  }

  /// Book event ticket
  static Future<Map<String, dynamic>> bookEvent({
    required int eventId,
    required int quantity,
    String? paymentIntentId,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/events/$eventId/book'),
      headers: _getHeaders(),
      body: json.encode({
        'quantity': quantity,
        'payment_intent_id': paymentIntentId,
      }),
    );

    return _handleResponse(response);
  }

  /// Get event attendee count
  static Future<int> getEventAttendeeCount(String eventId) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/events/$eventId/attendees/count'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return data['count'] as int;
  }

  /// Mark user as going to event (RSVP)
  static Future<Map<String, dynamic>> markEventGoing({
    required String eventId,
    required bool isGoing,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/events/$eventId/rsvp'),
      headers: _getHeaders(),
      body: json.encode({'is_going': isGoing}),
    );

    return _handleResponse(response);
  }

  /// Get list of users going to event
  static Future<List<Map<String, dynamic>>> getEventAttendees(
    String eventId,
  ) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/events/$eventId/attendees'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['attendees']);
  }

  /// Get event promotion/ad details
  static Future<Map<String, dynamic>> getEventPromotion(String eventId) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/events/$eventId/promotion'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  // ==================== REVIEWS ====================

  /// Submit a review for an event or organizer
  static Future<Map<String, dynamic>> submitReview({
    required String type,
    required String targetId,
    required double rating,
    required String reviewText,
    List<String>? photoUrls,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/reviews'),
      headers: _getHeaders(),
      body: json.encode({
        'type': type,
        'target_id': targetId,
        'rating': rating,
        'review_text': reviewText,
        'photo_urls': photoUrls,
      }),
    );

    return _handleResponse(response);
  }

  /// Get reviews for an event or organizer
  static Future<List<Map<String, dynamic>>> getReviews({
    required String type,
    required String targetId,
    int page = 1,
    int limit = 10,
  }) async {
    final queryParams = {
      'type': type,
      'target_id': targetId,
      'page': page.toString(),
      'limit': limit.toString(),
    };

    final uri = Uri.parse(
      '$_baseUrl/reviews',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    final data = _handleResponse(response);

    return List<Map<String, dynamic>>.from(data['reviews']);
  }

  /// Get review statistics (average rating, distribution)
  static Future<Map<String, dynamic>> getReviewStats({
    required String type,
    required String targetId,
  }) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/reviews/stats?type=$type&target_id=$targetId'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  // ==================== TRAVEL/BOOKINGS ====================

  /// Search flights
  static Future<List<Map<String, dynamic>>> searchFlights({
    required String origin,
    required String destination,
    required DateTime departDate,
    DateTime? returnDate,
  }) async {
    final queryParams = {
      'origin': origin,
      'destination': destination,
      'depart_date': departDate.toIso8601String(),
      if (returnDate != null) 'return_date': returnDate.toIso8601String(),
    };

    final uri = Uri.parse(
      '$_baseUrl/travel/flights',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    final data = _handleResponse(response);

    return List<Map<String, dynamic>>.from(data['flights']);
  }

  /// Search accommodations
  static Future<List<Map<String, dynamic>>> searchAccommodations({
    required String location,
    required DateTime checkIn,
    required DateTime checkOut,
    int guests = 1,
  }) async {
    final queryParams = {
      'location': location,
      'check_in': checkIn.toIso8601String(),
      'check_out': checkOut.toIso8601String(),
      'guests': guests.toString(),
    };

    final uri = Uri.parse(
      '$_baseUrl/travel/accommodations',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    final data = _handleResponse(response);

    return List<Map<String, dynamic>>.from(data['accommodations']);
  }

  // ==================== PAYMENTS ====================

  /// Process payment for event booking
  static Future<Map<String, dynamic>> processPayment({
    required int bookingId,
    required String paymentMethod,
    required double amount,
    Map<String, dynamic>? paymentDetails,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/payments'),
      headers: _getHeaders(),
      body: json.encode({
        'booking_id': bookingId,
        'payment_method': paymentMethod,
        'amount': amount,
        'payment_details': paymentDetails,
      }),
    );

    return _handleResponse(response);
  }

  /// Get payment history
  static Future<List<Map<String, dynamic>>> fetchPaymentHistory() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/payments/history'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['payments']);
  }

  // ==================== USER PROFILE ====================

  /// Get user profile
  static Future<Map<String, dynamic>> getUserProfile(int userId) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/users/$userId'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  /// Update user profile
  static Future<Map<String, dynamic>> updateProfile({
    String? fullName,
    String? bio,
    String? phone,
    String? avatarUrl,
  }) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/users/profile'),
      headers: _getHeaders(),
      body: json.encode({
        if (fullName != null) 'full_name': fullName,
        if (bio != null) 'bio': bio,
        if (phone != null) 'phone': phone,
        if (avatarUrl != null) 'avatar_url': avatarUrl,
      }),
    );

    final data = _handleResponse(response);
    _currentUser = data['user'];

    return data;
  }

  /// Search users
  static Future<List<Map<String, dynamic>>> searchUsers(String query) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/users/search?q=$query'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['users']);
  }

  // ==================== AI RECOMMENDATIONS ====================

  /// Track user interaction for AI recommendations
  static Future<void> trackInteraction({
    required String interactionType,
    int? postId,
    int? eventId,
    String? location,
    List<String>? tags,
  }) async {
    await http.post(
      Uri.parse('$_baseUrl/ai/track-interaction'),
      headers: _getHeaders(),
      body: json.encode({
        'interaction_type': interactionType,
        'post_id': postId,
        'event_id': eventId,
        'location': location,
        'tags': tags,
        'timestamp': DateTime.now().toIso8601String(),
      }),
    );
  }

  /// Get AI-powered recommendations
  static Future<Map<String, dynamic>> getRecommendations({
    int page = 1,
    int limit = 10,
  }) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/ai/recommendations?page=$page&limit=$limit'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  // ==================== TICKET WALLET ====================

  /// Get user's ticket wallet
  static Future<List<Map<String, dynamic>>> getTicketWallet() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/tickets/wallet'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['tickets']);
  }

  /// Get ticket details with QR code
  static Future<Map<String, dynamic>> getTicketDetails(String ticketId) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/tickets/$ticketId'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  /// Transfer ticket to another user
  static Future<Map<String, dynamic>> transferTicket({
    required String ticketId,
    required String recipientEmail,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/tickets/$ticketId/transfer'),
      headers: _getHeaders(),
      body: json.encode({'recipient_email': recipientEmail}),
    );

    return _handleResponse(response);
  }

  // ==================== ORGANIZER DASHBOARD ====================

  /// Get organizer analytics
  static Future<Map<String, dynamic>> getOrganizerAnalytics({
    String? dateRange,
  }) async {
    String url = '$_baseUrl/organizer/analytics';
    if (dateRange != null) {
      url += '?date_range=$dateRange';
    }

    final response = await http.get(Uri.parse(url), headers: _getHeaders());

    return _handleResponse(response);
  }

  /// Get ticket sales data
  static Future<List<Map<String, dynamic>>> getTicketSales({
    int? eventId,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final queryParams = {
      if (eventId != null) 'event_id': eventId.toString(),
      if (startDate != null) 'start_date': startDate.toIso8601String(),
      if (endDate != null) 'end_date': endDate.toIso8601String(),
    };

    final uri = Uri.parse(
      '$_baseUrl/organizer/ticket-sales',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    final data = _handleResponse(response);

    return List<Map<String, dynamic>>.from(data['sales']);
  }

  /// Get event check-in list
  static Future<List<Map<String, dynamic>>> getCheckInList(int eventId) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/organizer/events/$eventId/check-ins'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['check_ins']);
  }

  /// Send message to attendees
  static Future<void> messageAttendees({
    required int eventId,
    required String message,
  }) async {
    await http.post(
      Uri.parse('$_baseUrl/organizer/events/$eventId/message-attendees'),
      headers: _getHeaders(),
      body: json.encode({'message': message}),
    );
  }

  // ==================== VERIFICATION ====================

  /// Request verification
  static Future<Map<String, dynamic>> requestVerification({
    required String verificationType,
    required Map<String, dynamic> documents,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/verification/request'),
      headers: _getHeaders(),
      body: json.encode({
        'verification_type': verificationType,
        'documents': documents,
      }),
    );

    return _handleResponse(response);
  }

  /// Get verification status
  static Future<Map<String, dynamic>> getVerificationStatus() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/verification/status'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  // ==================== MONETIZATION ====================

  /// Purchase event boost
  static Future<Map<String, dynamic>> purchaseEventBoost({
    required int eventId,
    required String boostType,
    required int duration,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/monetization/boost'),
      headers: _getHeaders(),
      body: json.encode({
        'event_id': eventId,
        'boost_type': boostType,
        'duration': duration,
      }),
    );

    return _handleResponse(response);
  }

  /// Get monetization summary
  static Future<Map<String, dynamic>> getMonetizationSummary() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/monetization/summary'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  // ==================== VIBE STORIES ====================

  /// Create vibe story
  static Future<Map<String, dynamic>> createStory({
    required String mediaUrl,
    String? caption,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/stories'),
      headers: _getHeaders(),
      body: json.encode({
        'media_url': mediaUrl,
        'caption': caption,
        'expires_at': DateTime.now()
            .add(const Duration(hours: 24))
            .toIso8601String(),
      }),
    );

    return _handleResponse(response);
  }

  /// Get active stories
  static Future<List<Map<String, dynamic>>> getStories() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/stories'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['stories']);
  }

  /// View story (track analytics)
  static Future<void> viewStory(int storyId) async {
    await http.post(
      Uri.parse('$_baseUrl/stories/$storyId/view'),
      headers: _getHeaders(),
    );
  }

  // ==================== LIVE HEAT MAP ====================

  /// Get heat map data
  static Future<List<Map<String, dynamic>>> getHeatMapData({
    required double latitude,
    required double longitude,
    double radius = 50.0,
  }) async {
    final queryParams = {
      'latitude': latitude.toString(),
      'longitude': longitude.toString(),
      'radius': radius.toString(),
    };

    final uri = Uri.parse(
      '$_baseUrl/heatmap',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    final data = _handleResponse(response);

    return List<Map<String, dynamic>>.from(data['hotspots']);
  }

  // ==================== GROUP TRAVEL ====================

  /// Create group trip
  static Future<Map<String, dynamic>> createGroupTrip({
    required String title,
    required String destination,
    required DateTime startDate,
    required DateTime endDate,
    required List<String> memberEmails,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/group-travel/trips'),
      headers: _getHeaders(),
      body: json.encode({
        'title': title,
        'destination': destination,
        'start_date': startDate.toIso8601String(),
        'end_date': endDate.toIso8601String(),
        'member_emails': memberEmails,
      }),
    );

    return _handleResponse(response);
  }

  /// Get group trips
  static Future<List<Map<String, dynamic>>> getGroupTrips() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/group-travel/trips'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['trips']);
  }

  /// Update cost split
  static Future<Map<String, dynamic>> updateCostSplit({
    required String tripId,
    required Map<String, double> costSplit,
  }) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/group-travel/trips/$tripId/cost-split'),
      headers: _getHeaders(),
      body: json.encode({'cost_split': costSplit}),
    );

    return _handleResponse(response);
  }

  // ==================== EVENT TRAVEL BUNDLES ====================

  /// Get travel bundle for event
  static Future<Map<String, dynamic>> getEventTravelBundle(int eventId) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/events/$eventId/travel-bundle'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  // ==================== SAFETY & TRUST ====================

  /// Add trusted contact
  static Future<Map<String, dynamic>> addTrustedContact({
    required String name,
    required String phone,
    required String email,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/safety/trusted-contacts'),
      headers: _getHeaders(),
      body: json.encode({'name': name, 'phone': phone, 'email': email}),
    );

    return _handleResponse(response);
  }

  /// Get trusted contacts
  static Future<List<Map<String, dynamic>>> getTrustedContacts() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/safety/trusted-contacts'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['contacts']);
  }

  /// Share live location
  static Future<void> shareLiveLocation({
    required double latitude,
    required double longitude,
    required int eventId,
  }) async {
    await http.post(
      Uri.parse('$_baseUrl/safety/share-location'),
      headers: _getHeaders(),
      body: json.encode({
        'latitude': latitude,
        'longitude': longitude,
        'event_id': eventId,
        'timestamp': DateTime.now().toIso8601String(),
      }),
    );
  }

  /// Report fraud
  static Future<Map<String, dynamic>> reportFraud({
    required String reportType,
    required int targetId,
    required String description,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/safety/report-fraud'),
      headers: _getHeaders(),
      body: json.encode({
        'report_type': reportType,
        'target_id': targetId,
        'description': description,
      }),
    );

    return _handleResponse(response);
  }

  // ==================== ADMIN ====================

  /// Get pending verifications (admin only)
  static Future<List<Map<String, dynamic>>> getPendingVerifications() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/admin/verifications/pending'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['verifications']);
  }

  /// Approve verification (admin only)
  static Future<void> approveVerification(int verificationId) async {
    await http.post(
      Uri.parse('$_baseUrl/admin/verifications/$verificationId/approve'),
      headers: _getHeaders(),
    );
  }

  /// Reject verification (admin only)
  static Future<void> rejectVerification(
    int verificationId,
    String reason,
  ) async {
    await http.post(
      Uri.parse('$_baseUrl/admin/verifications/$verificationId/reject'),
      headers: _getHeaders(),
      body: json.encode({'reason': reason}),
    );
  }

  /// Get fraud alerts (admin only)
  static Future<List<Map<String, dynamic>>> getFraudAlerts() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/admin/fraud-alerts'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['alerts']);
  }

  /// Get platform revenue analytics (admin only)
  static Future<Map<String, dynamic>> getPlatformAnalytics({
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final queryParams = {
      if (startDate != null) 'start_date': startDate.toIso8601String(),
      if (endDate != null) 'end_date': endDate.toIso8601String(),
    };

    final uri = Uri.parse(
      '$_baseUrl/admin/analytics',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    return _handleResponse(response);
  }

  // ==================== MESSAGING ====================

  /// Fetch user conversations
  static Future<List<Map<String, dynamic>>> fetchConversations() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/messages/conversations'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data['conversations']);
  }

  // ==================== NOTIFICATIONS ====================

  /// Get unread notification count by category
  static Future<Map<String, int>> getUnreadCountByCategory() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/notifications/unread-count'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return Map<String, int>.from(data['counts']);
  }

  /// Fetch notifications with optional category filter
  static Future<List<Map<String, dynamic>>> fetchNotifications({
    String? category,
    int page = 1,
    int limit = 20,
  }) async {
    final queryParams = {
      if (category != null) 'category': category,
      'page': page.toString(),
      'limit': limit.toString(),
    };

    final uri = Uri.parse(
      '$_baseUrl/notifications',
    ).replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _getHeaders());
    final data = _handleResponse(response);

    return List<Map<String, dynamic>>.from(data['notifications']);
  }

  /// Mark notification as read
  static Future<void> markNotificationAsRead(String notificationId) async {
    await http.put(
      Uri.parse('$_baseUrl/notifications/$notificationId/read'),
      headers: _getHeaders(),
    );
  }

  /// Mark all notifications as read
  static Future<void> markAllNotificationsAsRead({String? category}) async {
    final queryParams = {if (category != null) 'category': category};

    final uri = Uri.parse(
      '$_baseUrl/notifications/read-all',
    ).replace(queryParameters: queryParams);

    await http.put(uri, headers: _getHeaders());
  }

  /// Delete notification
  static Future<void> deleteNotification(String notificationId) async {
    await http.delete(
      Uri.parse('$_baseUrl/notifications/$notificationId'),
      headers: _getHeaders(),
    );
  }

  /// Get unread notification count
  static Future<int> getUnreadNotificationCount() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/notifications/unread-count/total'),
      headers: _getHeaders(),
    );

    final data = _handleResponse(response);
    return data['count'] as int;
  }

  /// Get notification preferences
  static Future<Map<String, dynamic>> getNotificationPreferences() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/notifications/preferences'),
      headers: _getHeaders(),
    );

    return _handleResponse(response);
  }

  /// Update notification preferences
  static Future<Map<String, dynamic>> updateNotificationPreferences({
    required Map<String, dynamic> preferences,
  }) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/notifications/preferences'),
      headers: _getHeaders(),
      body: json.encode({'preferences': preferences}),
    );

    return _handleResponse(response);
  }

  // ==================== EVENT PROMOTION ====================

  /// Create event ad/promotion
  static Future<Map<String, dynamic>> createEventAd({
    required String eventId,
    required String adType,
    required double budget,
    required int durationDays,
    String? targetAudience,
  }) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/events/$eventId/ads'),
      headers: _getHeaders(),
      body: json.encode({
        'ad_type': adType,
        'budget': budget,
        'duration_days': durationDays,
        'target_audience': targetAudience,
      }),
    );

    return _handleResponse(response);
  }
}

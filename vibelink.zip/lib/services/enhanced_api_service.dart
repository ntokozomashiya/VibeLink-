import 'dart:async';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

/// Enhanced API Service with retry mechanisms and error handling
class EnhancedApiService {
  static final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      sendTimeout: const Duration(seconds: 15),
    ),
  );

  static final Connectivity _connectivity = Connectivity();
  static StreamController<bool>? _connectionStatusController;

  /// Initialize API service with interceptors
  static void initialize() {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          // Check connectivity before request
          final hasConnection = await checkConnectivity();
          if (!hasConnection) {
            return handler.reject(
              DioException(
                requestOptions: options,
                type: DioExceptionType.connectionError,
                error: 'No internet connection',
              ),
            );
          }
          return handler.next(options);
        },
        onError: (error, handler) async {
          // Retry logic for specific errors
          if (_shouldRetry(error)) {
            try {
              final response = await _retryRequest(error.requestOptions);
              return handler.resolve(response);
            } catch (e) {
              return handler.next(error);
            }
          }
          return handler.next(error);
        },
      ),
    );
  }

  /// Check network connectivity
  static Future<bool> checkConnectivity() async {
    try {
      final result = await _connectivity.checkConnectivity();
      return result.first != ConnectivityResult.none;
    } catch (e) {
      return false;
    }
  }

  /// Get connectivity status stream
  static Stream<bool> getConnectionStatusStream() {
    _connectionStatusController ??= StreamController<bool>.broadcast();

    _connectivity.onConnectivityChanged.listen((results) {
      final isConnected = results.first != ConnectivityResult.none;
      _connectionStatusController?.add(isConnected);
    });

    return _connectionStatusController!.stream;
  }

  /// Determine if request should be retried
  static bool _shouldRetry(DioException error) {
    return error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout ||
        error.type == DioExceptionType.sendTimeout ||
        (error.response?.statusCode != null &&
            error.response!.statusCode! >= 500);
  }

  /// Retry failed request with exponential backoff
  static Future<Response> _retryRequest(
    RequestOptions requestOptions, {
    int maxRetries = 3,
  }) async {
    int retryCount = 0;

    while (retryCount < maxRetries) {
      try {
        // Exponential backoff: 1s, 2s, 4s
        await Future.delayed(Duration(seconds: 1 << retryCount));

        // Check connectivity before retry
        final hasConnection = await checkConnectivity();
        if (!hasConnection) {
          throw DioException(
            requestOptions: requestOptions,
            type: DioExceptionType.connectionError,
            error: 'No internet connection',
          );
        }

        // Retry the request
        return await _dio.fetch(requestOptions);
      } on DioException {
        retryCount++;
        if (retryCount >= maxRetries) {
          rethrow;
        }
      }
    }

    throw DioException(
      requestOptions: requestOptions,
      error: 'Max retries exceeded',
    );
  }

  /// Make GET request with retry
  static Future<Response> get(
    String url, {
    Map<String, dynamic>? queryParameters,
    Map<String, String>? headers,
  }) async {
    try {
      return await _dio.get(
        url,
        queryParameters: queryParameters,
        options: Options(headers: headers),
      );
    } on DioException catch (e) {
      throw _handleApiError(e);
    }
  }

  /// Make POST request with retry
  static Future<Response> post(
    String url, {
    dynamic data,
    Map<String, String>? headers,
  }) async {
    try {
      return await _dio.post(
        url,
        data: data,
        options: Options(headers: headers),
      );
    } on DioException catch (e) {
      throw _handleApiError(e);
    }
  }

  /// Make PUT request with retry
  static Future<Response> put(
    String url, {
    dynamic data,
    Map<String, String>? headers,
  }) async {
    try {
      return await _dio.put(
        url,
        data: data,
        options: Options(headers: headers),
      );
    } on DioException catch (e) {
      throw _handleApiError(e);
    }
  }

  /// Make DELETE request with retry
  static Future<Response> delete(
    String url, {
    Map<String, String>? headers,
  }) async {
    try {
      return await _dio.delete(url, options: Options(headers: headers));
    } on DioException catch (e) {
      throw _handleApiError(e);
    }
  }

  /// Handle API errors with user-friendly messages
  static ApiException _handleApiError(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return ApiException(
          message:
              'Request timeout. Please check your connection and try again.',
          type: ApiErrorType.timeout,
          originalError: error,
        );

      case DioExceptionType.connectionError:
        return ApiException(
          message: 'No internet connection. Please check your network.',
          type: ApiErrorType.network,
          originalError: error,
        );

      case DioExceptionType.badResponse:
        final statusCode = error.response?.statusCode ?? 0;
        if (statusCode >= 500) {
          return ApiException(
            message: 'Server error. Please try again later.',
            type: ApiErrorType.server,
            statusCode: statusCode,
            originalError: error,
          );
        } else if (statusCode == 401) {
          return ApiException(
            message: 'Session expired. Please login again.',
            type: ApiErrorType.authentication,
            statusCode: statusCode,
            originalError: error,
          );
        } else if (statusCode == 403) {
          return ApiException(
            message: 'Access denied. You don\'t have permission.',
            type: ApiErrorType.authorization,
            statusCode: statusCode,
            originalError: error,
          );
        } else if (statusCode == 404) {
          return ApiException(
            message: 'Resource not found.',
            type: ApiErrorType.notFound,
            statusCode: statusCode,
            originalError: error,
          );
        } else {
          return ApiException(
            message: 'Request failed. Please try again.',
            type: ApiErrorType.badRequest,
            statusCode: statusCode,
            originalError: error,
          );
        }

      case DioExceptionType.cancel:
        return ApiException(
          message: 'Request cancelled.',
          type: ApiErrorType.cancelled,
          originalError: error,
        );

      default:
        return ApiException(
          message: 'An unexpected error occurred. Please try again.',
          type: ApiErrorType.unknown,
          originalError: error,
        );
    }
  }

  /// Dispose resources
  static void dispose() {
    _connectionStatusController?.close();
    _connectionStatusController = null;
  }
}

/// API Error Types
enum ApiErrorType {
  network,
  timeout,
  server,
  authentication,
  authorization,
  notFound,
  badRequest,
  cancelled,
  unknown,
}

/// Custom API Exception
class ApiException implements Exception {
  final String message;
  final ApiErrorType type;
  final int? statusCode;
  final DioException? originalError;

  ApiException({
    required this.message,
    required this.type,
    this.statusCode,
    this.originalError,
  });

  @override
  String toString() => message;

  /// Check if error is retryable
  bool get isRetryable {
    return type == ApiErrorType.network ||
        type == ApiErrorType.timeout ||
        type == ApiErrorType.server;
  }
}

# VibeLink - Oracle VPS Integration Guide

## Overview
VibeLink is now fully configured to work with Oracle VPS hosting and Oracle Database. All backend operations, authentication, real-time messaging, and data storage are designed to integrate seamlessly with Oracle infrastructure.

## Architecture

### Frontend (Flutter App)
- **Platform**: Flutter 3.16+ / Dart 3.2+
- **API Communication**: HTTP REST APIs via `http` package
- **Real-time Messaging**: WebSocket connections via `web_socket_channel` package
- **Authentication**: JWT token-based with SHA-256 password hashing

### Backend (Oracle VPS)
- **Hosting**: Oracle VPS (Virtual Private Server)
- **Database**: Oracle Autonomous Database or Oracle MySQL
- **API Framework**: Node.js/Express, Python/FastAPI, or Java/Spring Boot (your choice)
- **WebSocket Server**: Real-time messaging for chat functionality
- **File Storage**: Oracle Object Storage for media files

## Database Schema

The complete Oracle SQL schema is provided in `ORACLE_BACKEND_SETUP.md` and includes:

### Core Tables
1. **users** - User accounts and profiles
2. **posts** - Social media posts/vibes
3. **post_likes** - Post like tracking
4. **comments** - Post comments
5. **events** - Event listings
6. **event_bookings** - Event ticket bookings
7. **conversations** - Chat conversations
8. **conversation_participants** - Conversation membership
9. **messages** - Chat messages
10. **payments** - Payment transactions
11. **travel_bookings** - Flight/accommodation bookings

### Key Features
- Auto-incrementing primary keys using Oracle IDENTITY columns
- Foreign key constraints with CASCADE delete
- Indexes on frequently queried columns
- CLOB fields for large text and JSON data
- Timestamp tracking for all records

## API Services

### OracleApiService (`lib/services/oracle_api_service.dart`)
Handles all REST API communication with the Oracle backend.

#### Authentication
- `login(email, password)` - User login
- `register(...)` - User registration
- `setupOrganizerProfile(...)` - Organizer account setup
- `logout()` - User logout

#### Posts/Vibes
- `fetchPosts(page, limit)` - Get posts feed
- `createPost(...)` - Create new post
- `likePost(postId)` - Like a post
- `unlikePost(postId)` - Unlike a post
- `addComment(postId, comment)` - Add comment

#### Events
- `fetchEvents(...)` - Search events with filters
- `createEvent(...)` - Create new event
- `bookEvent(eventId, quantity)` - Book event tickets

#### Messaging
- `fetchConversations()` - Get conversation list
- `fetchMessages(conversationId)` - Get messages
- `sendMessage(conversationId, message)` - Send message

#### Travel
- `searchFlights(...)` - Search flights
- `searchAccommodations(...)` - Search stays

#### Payments
- `processPayment(...)` - Process payment
- `fetchPaymentHistory()` - Get payment history

#### User Profile
- `getUserProfile(userId)` - Get user profile
- `updateProfile(...)` - Update profile
- `searchUsers(query)` - Search users

### OracleWebSocketService (`lib/services/oracle_websocket_service.dart`)
Handles real-time WebSocket communication for messaging.

#### Methods
- `connect(authToken)` - Connect to WebSocket server
- `disconnect()` - Disconnect from server
- `sendChatMessage(...)` - Send chat message
- `sendTypingIndicator(...)` - Send typing status
- `joinConversation(conversationId)` - Join chat room
- `leaveConversation(conversationId)` - Leave chat room

#### Event Handling
- Listens to `messageStream` for incoming messages
- Handles `chat_message`, `typing`, and other events
- Automatic reconnection on connection loss

## Environment Configuration

### Flutter App Environment Variables
Add these to your `env.json` file:

```json
{
  "ORACLE_API_BASE_URL": "https://your-oracle-vps.com/api",
  "ORACLE_API_KEY": "your-api-key-here",
  "ORACLE_WS_URL": "wss://your-oracle-vps.com/ws"
}
```

### Backend Environment Variables
Configure these on your Oracle VPS:

```bash
DATABASE_HOST=your-oracle-db-host
DATABASE_PORT=1521
DATABASE_NAME=vibelink
DATABASE_USER=admin
DATABASE_PASSWORD=your-secure-password
JWT_SECRET=your-jwt-secret-key
API_KEY=your-api-key
WS_PORT=8080
```

## Deployment Steps

### 1. Oracle VPS Setup
1. Provision Oracle VPS instance
2. Install required software (Node.js/Python/Java)
3. Configure firewall rules (ports 80, 443, 8080)
4. Set up SSL certificates for HTTPS/WSS

### 2. Oracle Database Setup
1. Create Oracle Autonomous Database or MySQL instance
2. Execute all table creation scripts from `ORACLE_BACKEND_SETUP.md`
3. Create database indexes
4. Set up backup procedures

### 3. Backend Application Deployment
1. Deploy backend application to Oracle VPS
2. Configure environment variables
3. Set up process manager (PM2, systemd)
4. Configure reverse proxy (Nginx, Apache)
5. Enable WebSocket support in proxy

### 4. Flutter App Configuration
1. Update `env.json` with production URLs
2. Update API keys
3. Build Flutter app for production
4. Test all API endpoints

### 5. Testing Checklist
- [ ] User registration and login
- [ ] Post creation and feed loading
- [ ] Event creation and booking
- [ ] Real-time messaging
- [ ] Payment processing
- [ ] Travel search functionality
- [ ] Profile updates
- [ ] WebSocket reconnection

## Security Features

### Authentication
- JWT token-based authentication
- SHA-256 password hashing
- Token expiration and refresh
- API key validation on all requests

### API Security
- HTTPS encryption for all API calls
- WSS encryption for WebSocket connections
- SQL injection prevention via parameterized queries
- Rate limiting on endpoints
- Input validation and sanitization

### Data Protection
- Passwords never stored in plain text
- Sensitive data encrypted at rest
- Secure token storage
- CORS configuration

## API Endpoint Reference

All endpoints are prefixed with `ORACLE_API_BASE_URL`.

### Authentication Endpoints
```
POST /auth/login
POST /auth/register
POST /auth/setup-organizer
POST /auth/logout
```

### Posts Endpoints
```
GET  /posts?page={page}&limit={limit}
POST /posts
POST /posts/{postId}/like
DELETE /posts/{postId}/like
POST /posts/{postId}/comments
```

### Events Endpoints
```
GET  /events?category={cat}&location={loc}&start_date={date}&end_date={date}
POST /events
POST /events/{eventId}/book
```

### Messaging Endpoints
```
GET  /messages/conversations
GET  /messages/conversations/{conversationId}
POST /messages/conversations/{conversationId}
```

### Travel Endpoints
```
GET /travel/flights?origin={origin}&destination={dest}&depart_date={date}
GET /travel/accommodations?location={loc}&check_in={date}&check_out={date}
```

### Payment Endpoints
```
POST /payments
GET  /payments/history
```

### User Endpoints
```
GET /users/{userId}
PUT /users/profile
GET /users/search?q={query}
```

## WebSocket Events

### Client → Server
```json
{
  "type": "chat_message",
  "conversation_id": 123,
  "message": "Hello!",
  "media_url": null,
  "timestamp": "2026-01-05T18:00:00Z"
}
```

### Server → Client
```json
{
  "type": "chat_message",
  "conversation_id": 123,
  "sender_id": 456,
  "message": "Hi there!",
  "timestamp": "2026-01-05T18:00:01Z"
}
```

## Error Handling

### API Errors
All API errors return standard HTTP status codes:
- `200-299`: Success
- `400`: Bad request
- `401`: Unauthorized
- `403`: Forbidden
- `404`: Not found
- `500`: Server error

### Error Response Format
```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "details": {}
}
```

### Client-Side Error Handling
The app handles errors gracefully:
- Network errors show user-friendly messages
- Failed API calls don't crash the app
- Automatic retry for transient failures
- Offline mode support where applicable

## Performance Optimization

### Database
- Indexes on frequently queried columns
- Connection pooling
- Query optimization
- Caching for read-heavy operations

### API
- Pagination for large datasets
- Response compression
- CDN for static assets
- Rate limiting to prevent abuse

### WebSocket
- Connection pooling
- Message batching
- Automatic reconnection
- Heartbeat monitoring

## Monitoring and Logging

### Backend Monitoring
- API response times
- Database query performance
- WebSocket connection count
- Error rates and types
- Resource utilization (CPU, memory, disk)

### Logging
- API request/response logs
- Error logs with stack traces
- Authentication attempts
- Database queries
- WebSocket events

## Backup and Recovery

### Database Backups
- Daily automated backups
- Point-in-time recovery
- Backup retention policy
- Disaster recovery plan

### Application Backups
- Code repository backups
- Configuration backups
- Media file backups

## Support and Maintenance

### Regular Maintenance
- Database optimization
- Log rotation
- Security updates
- Performance tuning
- Backup verification

### Scaling Considerations
- Horizontal scaling for API servers
- Database read replicas
- Load balancing
- CDN for media files
- Caching layer (Redis)

## Troubleshooting

### Common Issues

**Connection Errors**
- Verify `ORACLE_API_BASE_URL` is correct
- Check firewall rules
- Verify SSL certificates
- Check API key configuration

**Authentication Failures**
- Verify JWT secret matches
- Check token expiration
- Verify password hashing algorithm

**WebSocket Issues**
- Verify `ORACLE_WS_URL` is correct
- Check WebSocket port is open
- Verify proxy WebSocket support
- Check authentication token

**Database Errors**
- Verify connection string
- Check database credentials
- Verify tables exist
- Check database permissions

## Additional Resources

- **Oracle Cloud Documentation**: https://docs.oracle.com/en-us/iaas/
- **Oracle Database Documentation**: https://docs.oracle.com/en/database/
- **Flutter Documentation**: https://docs.flutter.dev/
- **WebSocket Protocol**: https://datatracker.ietf.org/doc/html/rfc6455

## Contact and Support

For technical support or questions about the Oracle integration:
1. Review this documentation
2. Check `ORACLE_BACKEND_SETUP.md` for backend details
3. Verify environment configuration
4. Check backend logs for errors

---

**Last Updated**: January 5, 2026
**Version**: 1.0.0
**Compatible with**: Flutter 3.16+, Oracle Database 19c+, Oracle MySQL 8.0+
